import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KIND_LABEL } from "@/lib/dispatch/seed";
import { useDispatch } from "@/lib/dispatch/store";
import { formatClock } from "@/lib/utils";

const tone = {
  info: "info" as const,
  watch: "warn" as const,
  critical: "danger" as const,
};

export function EventsView() {
  const events = useDispatch((s) => s.events);
  const acknowledgeEvent = useDispatch((s) => s.acknowledgeEvent);
  const injectEvent = useDispatch((s) => s.injectEvent);
  const setView = useDispatch((s) => s.setView);
  const selectLoad = useDispatch((s) => s.selectLoad);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex flex-wrap gap-2">
        <Button size="sm" variant="secondary" onClick={() => injectEvent("weather")}>
          Fog event
        </Button>
        <Button size="sm" variant="secondary" onClick={() => injectEvent("chassis")}>
          Chassis lockout
        </Button>
        <Button size="sm" variant="outline" onClick={() => setView("planner")}>
          Replan from events
        </Button>
      </div>
      <ul className="space-y-2 overflow-auto">
        {events.map((ev) => (
          <li
            key={ev.id}
            className={`rounded-lg bg-surface p-4 shadow-panel ${ev.acknowledged ? "opacity-60" : ""}`}
          >
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone={tone[ev.severity]}>{ev.severity}</Badge>
              <Badge>{KIND_LABEL[ev.kind] ?? ev.kind}</Badge>
              <span className="font-mono text-xs text-muted">{formatClock(ev.at)}</span>
            </div>
            <h3 className="mt-2 text-sm font-medium">{ev.title}</h3>
            <p className="mt-1 text-sm text-muted">{ev.detail}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {!ev.acknowledged ? (
                <Button size="sm" variant="secondary" onClick={() => acknowledgeEvent(ev.id)}>
                  Acknowledge
                </Button>
              ) : null}
              {ev.loadId ? (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => {
                    selectLoad(ev.loadId!);
                    setView("dispatch");
                  }}
                >
                  Open move
                </Button>
              ) : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
