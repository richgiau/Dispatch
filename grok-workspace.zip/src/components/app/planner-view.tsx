import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { localReplan } from "@/lib/dispatch/local-plan";
import { askDispatchAi, runDispatchPlan } from "@/lib/dispatch/planner";
import { buildPlannerSnapshot, useDispatch } from "@/lib/dispatch/store";
import { formatClock, formatMinutes } from "@/lib/utils";

export function PlannerView() {
  const addPlan = useDispatch((s) => s.addPlan);
  const applyRecommendation = useDispatch((s) => s.applyRecommendation);
  const dismissRecommendation = useDispatch((s) => s.dismissRecommendation);
  const applyAllRecommendations = useDispatch((s) => s.applyAllRecommendations);
  const sendMail = useDispatch((s) => s.sendMail);
  const plans = useDispatch((s) => s.plans);
  const [busy, setBusy] = useState(false);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [source, setSource] = useState<"grok" | "rules" | null>(null);
  const latest = plans[0];

  async function replan() {
    setBusy(true);
    setAnswer(null);
    try {
      const live = useDispatch.getState();
      const snapshot = buildPlannerSnapshot(live);
      const res = await runDispatchPlan({
        data: {
          snapshot,
          question: question.trim() || undefined,
        },
      });
      if (res.ok && res.plan.recommendations.length > 0) {
        addPlan(res.plan);
        setSource("grok");
        toast.success("Grok plan ready — review before pushing to MC3.");
        return;
      }
      addPlan(localReplan(live));
      setSource("rules");
      toast.message(res.ok ? "Rules engine used — Grok returned no moves." : `Grok unavailable (${res.error}). Used the harbor rules engine.`);
    } catch {
      addPlan(localReplan(useDispatch.getState()));
      setSource("rules");
      toast.message("Grok unreachable. Used the harbor rules engine.");
    } finally {
      setBusy(false);
    }
  }

  async function ask() {
    if (!question.trim()) {
      toast.error("Type a dispatch question.");
      return;
    }
    setBusy(true);
    try {
      const snapshot = buildPlannerSnapshot(useDispatch.getState());
      const res = await askDispatchAi({ data: { snapshot, question } });
      if (!res.ok) {
        toast.error(res.error);
        const plan = localReplan(useDispatch.getState());
        setAnswer(plan.summary);
        return;
      }
      setAnswer(res.text);
    } catch {
      toast.error("Planner could not answer.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4 lg:flex-row">
      <div className="flex w-full flex-col gap-3 lg:w-[380px]">
        <div className="rounded-lg bg-surface p-4 shadow-panel">
          <h2 className="text-sm font-medium">AI dispatch</h2>
          <p className="mt-1 text-sm text-muted">
            Reads live waits, lines, traffic, HOS, and unplanned events, then proposes routing and MC3 assignment changes.
          </p>
          <Textarea
            className="mt-3"
            placeholder="Optional: hold APM duals, rescue 2180, flip Brooks…"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          <div className="mt-3 flex flex-wrap gap-2">
            <Button onClick={replan} disabled={busy}>
              {busy ? <span className="shimmer-text">Scanning conditions</span> : "Replan board"}
            </Button>
            <Button variant="secondary" onClick={ask} disabled={busy}>
              Ask
            </Button>
          </div>
          {source === "rules" ? (
            <p className="mt-2 text-xs text-muted">Showing the harbor rules engine. Grok will take over when the API is available.</p>
          ) : null}
        </div>
        {answer ? (
          <div className="rounded-lg bg-surface p-4 text-sm leading-relaxed text-fg shadow-panel whitespace-pre-wrap">
            {answer}
          </div>
        ) : null}
      </div>

      <div className="min-w-0 flex-1 overflow-auto">
        {!latest ? (
          <div className="rounded-lg bg-surface p-8 text-center text-sm text-muted shadow-panel">
            Run a replan when traffic, terminal lines, or a breakdown change the night.
          </div>
        ) : (
          <div className="space-y-3">
            <div className="rounded-lg bg-surface p-4 shadow-panel">
              <div className="flex flex-wrap items-center gap-2">
                <Badge
                  tone={
                    latest.riskLevel === "severe"
                      ? "danger"
                      : latest.riskLevel === "elevated"
                        ? "warn"
                        : "ok"
                  }
                >
                  {latest.riskLevel}
                </Badge>
                <span className="font-mono text-xs text-muted">{formatClock(latest.at)}</span>
              </div>
              <p className="mt-2 text-sm leading-relaxed">{latest.summary}</p>
              <Button
                className="mt-3"
                size="sm"
                onClick={() => {
                  applyAllRecommendations(latest.id);
                  toast.success("Applied to the board. MC3 push queued where connected.");
                }}
              >
                Apply all
              </Button>
            </div>
            {latest.recommendations.map((r) => (
              <article key={r.id} className="rounded-lg bg-surface p-4 shadow-panel">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone="primary">{r.type}</Badge>
                  {r.minutesSaved > 0 ? (
                    <Badge tone="ok">{formatMinutes(r.minutesSaved)} saved</Badge>
                  ) : null}
                  <Badge
                    tone={
                      r.status === "applied" ? "ok" : r.status === "dismissed" ? "muted" : "warn"
                    }
                  >
                    {r.status}
                  </Badge>
                </div>
                <h3 className="mt-2 text-sm font-medium">{r.title}</h3>
                <p className="mt-1 text-sm text-muted">{r.rationale}</p>
                {r.newRoute ? (
                  <p className="mt-2 font-mono text-xs text-primary">{r.newRoute}</p>
                ) : null}
                {r.emailDraft ? (
                  <p className="mt-2 text-xs text-muted">
                    Draft to {r.emailDraft.to}: {r.emailDraft.subject}
                  </p>
                ) : null}
                {r.status === "proposed" ? (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Button
                      size="sm"
                      onClick={() => {
                        applyRecommendation(latest.id, r.id);
                        toast.success("Change applied.");
                      }}
                    >
                      Apply
                    </Button>
                    {r.emailDraft ? (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => {
                          sendMail({
                            to: r.emailDraft!.to,
                            subject: r.emailDraft!.subject,
                            body: r.emailDraft!.body,
                            kind: "plan",
                            loadId: r.loadId,
                            driverId: r.driverId,
                          });
                          toast.success("Email filed to Sent.");
                        }}
                      >
                        Send email
                      </Button>
                    ) : null}
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => dismissRecommendation(latest.id, r.id)}
                    >
                      Dismiss
                    </Button>
                  </div>
                ) : null}
              </article>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
