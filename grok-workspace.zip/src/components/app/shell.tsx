import { useEffect, useState } from "react";
import {
  Activity,
  Container,
  Mail,
  Map,
  Radio,
  Settings,
  TriangleAlert,
  Truck,
} from "lucide-react";
import { ConditionsView } from "@/components/app/conditions-view";
import { DispatchBoard } from "@/components/app/dispatch-board";
import { EventsView } from "@/components/app/events-view";
import { FleetView } from "@/components/app/fleet-view";
import { MailView } from "@/components/app/mail-view";
import { PlannerView } from "@/components/app/planner-view";
import { SettingsView } from "@/components/app/settings-view";
import { LiveDot } from "@/components/app/status-chip";
import { useDispatch } from "@/lib/dispatch/store";
import type { ViewId } from "@/lib/dispatch/types";
import { cn, formatClock } from "@/lib/utils";

const NAV: { id: ViewId; label: string; icon: typeof Container }[] = [
  { id: "dispatch", label: "Dispatch", icon: Container },
  { id: "conditions", label: "Conditions", icon: Map },
  { id: "fleet", label: "Fleet", icon: Truck },
  { id: "events", label: "Events", icon: TriangleAlert },
  { id: "mail", label: "Mail", icon: Mail },
  { id: "planner", label: "Planner", icon: Activity },
  { id: "settings", label: "Links", icon: Settings },
];

const MOBILE_NAV: ViewId[] = ["dispatch", "conditions", "mail", "planner", "settings"];

export function DispatchShell() {
  const view = useDispatch((s) => s.view);
  const setView = useDispatch((s) => s.setView);
  const mc3 = useDispatch((s) => s.mc3);
  const mailbox = useDispatch((s) => s.mailbox);
  const events = useDispatch((s) => s.events);
  const mail = useDispatch((s) => s.mail);
  const tickSim = useDispatch((s) => s.tickSim);
  const syncMc3 = useDispatch((s) => s.syncMc3);
  const [clock, setClock] = useState(() => Date.now());

  useEffect(() => {
    const a = window.setInterval(() => setClock(Date.now()), 15000);
    const b = window.setInterval(() => tickSim(), 8000);
    const c = window.setInterval(() => {
      if (useDispatch.getState().mc3.connected) syncMc3();
    }, 28000);
    return () => {
      window.clearInterval(a);
      window.clearInterval(b);
      window.clearInterval(c);
    };
  }, [tickSim, syncMc3]);

  const unread = mail.filter((m) => m.folder === "inbox" && !m.read).length;
  const openEvents = events.filter((e) => !e.acknowledged && e.severity !== "info").length;

  return (
    <div className="flex min-h-dvh bg-bg text-fg">
      <aside className="hidden w-[220px] shrink-0 flex-col border-r border-border bg-surface md:flex">
        <div className="px-4 py-5">
          <p className="font-medium tracking-tight">Pierline</p>
          <p className="text-xs text-muted">Pacific Gate Drayage</p>
        </div>
        <nav className="flex flex-1 flex-col gap-0.5 px-2">
          {NAV.map((item) => {
            const Icon = item.icon;
            const badge =
              item.id === "mail" ? unread : item.id === "events" ? openEvents : 0;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setView(item.id)}
                className={cn(
                  "flex h-11 items-center gap-2 rounded-sm px-3 text-sm transition-colors duration-150",
                  view === item.id ? "bg-raised text-fg" : "text-muted hover:bg-raised/60 hover:text-fg",
                )}
              >
                <Icon className="size-4" />
                <span className="flex-1 text-left">{item.label}</span>
                {badge > 0 ? (
                  <span className="min-w-5 rounded-full bg-danger/20 px-1.5 text-center font-mono text-[10px] tabular-nums text-danger">
                    {badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-border px-4 py-4 text-xs text-muted">
          <LiveDot on={mc3.connected} />
          <p className="mt-1">{mailbox.connected ? mailbox.address : "Mailbox local"}</p>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 items-center justify-between gap-3 border-b border-border px-4">
          <div className="min-w-0">
            <h1 className="truncate text-sm font-medium md:hidden">Pierline</h1>
            <p className="hidden text-sm text-muted md:block">
              Harbor night shift · traffic, lines, waiting time
            </p>
          </div>
          <div className="flex items-center gap-2 font-mono text-xs tabular-nums text-muted">
            {openEvents > 0 ? (
              <button
                type="button"
                onClick={() => setView("events")}
                className="h-11 rounded-full bg-danger/15 px-3 text-danger"
              >
                {openEvents} events
              </button>
            ) : null}
            <span className="hidden sm:inline">{formatClock(clock)}</span>
            <button
              type="button"
              onClick={() => setView("settings")}
              className="inline-flex h-11 items-center gap-1 px-2"
            >
              <Radio className="size-3.5" />
              {mc3.connected ? "MC3" : "offline"}
            </button>
          </div>
        </header>

        <main className="flex min-h-0 flex-1 flex-col overflow-auto p-3 pb-24 md:p-5 md:pb-5">
          {view === "dispatch" ? <DispatchBoard /> : null}
          {view === "conditions" ? <ConditionsView /> : null}
          {view === "fleet" ? <FleetView /> : null}
          {view === "events" ? <EventsView /> : null}
          {view === "mail" ? <MailView /> : null}
          {view === "planner" ? <PlannerView /> : null}
          {view === "settings" ? <SettingsView /> : null}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV.filter((n) => MOBILE_NAV.includes(n.id)).map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              className={cn(
                "flex h-14 flex-col items-center justify-center gap-0.5 text-[10px]",
                view === item.id ? "text-primary" : "text-muted",
              )}
            >
              <Icon className="size-4" />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
