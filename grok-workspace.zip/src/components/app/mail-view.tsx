import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { KIND_LABEL } from "@/lib/dispatch/seed";
import { useDispatch } from "@/lib/dispatch/store";
import type { MailFolder } from "@/lib/dispatch/types";
import { cn, formatClock } from "@/lib/utils";
import { toast } from "sonner";

export function MailView() {
  const mail = useDispatch((s) => s.mail);
  const selectedMailId = useDispatch((s) => s.selectedMailId);
  const selectMail = useDispatch((s) => s.selectMail);
  const markMailRead = useDispatch((s) => s.markMailRead);
  const sendMail = useDispatch((s) => s.sendMail);
  const mailbox = useDispatch((s) => s.mailbox);
  const pullMail = useDispatch((s) => s.pullMail);
  const drivers = useDispatch((s) => s.drivers);
  const loads = useDispatch((s) => s.loads);
  const selectLoad = useDispatch((s) => s.selectLoad);
  const setView = useDispatch((s) => s.setView);

  const [folder, setFolder] = useState<MailFolder>("inbox");
  const [composing, setComposing] = useState(false);
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  const list = useMemo(
    () => mail.filter((m) => m.folder === folder),
    [mail, folder],
  );
  const selected = mail.find((m) => m.id === selectedMailId) ?? list[0];

  function send() {
    if (!to.trim() || !subject.trim()) {
      toast.error("Add a recipient and subject.");
      return;
    }
    sendMail({ to, subject, body, kind: "plan" });
    setTo("");
    setSubject("");
    setBody("");
    setComposing(false);
    setFolder("sent");
    toast.success(mailbox.connected ? "Sent from dispatch mailbox." : "Filed to Sent.");
  }

  function replyTemplate() {
    if (!selected) return;
    const driver = drivers.find((d) => d.id === selected.driverId);
    const load = loads.find((l) => l.id === selected.loadId);
    setComposing(true);
    setTo(selected.kind === "driver" ? selected.from : driver?.email || selected.from);
    setSubject(`Re: ${selected.subject}`);
    setBody(
      load
        ? `Updated plan for ${load.container} (${load.mc3MoveId}).\nRoute: ${load.route}\nStatus: ${load.status}\n\n— Pierline dispatch`
        : "Acknowledged. We are adjusting the plan.\n\n— Pierline dispatch",
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3 lg:flex-row">
      <div className="flex w-full shrink-0 flex-col lg:w-[320px]">
        <div className="mb-2 flex gap-1">
          {(["inbox", "sent", "drafts"] as MailFolder[]).map((f) => (
            <button
              key={f}
              type="button"
              onClick={() => setFolder(f)}
              className={cn(
                "h-9 flex-1 rounded-full text-xs font-medium capitalize",
                folder === f ? "bg-primary text-primary-fg" : "bg-raised text-muted",
              )}
            >
              {f}
              {f === "inbox" ? (
                <span className="ml-1 tabular-nums">
                  {mail.filter((m) => m.folder === "inbox" && !m.read).length || ""}
                </span>
              ) : null}
            </button>
          ))}
        </div>
        <div className="mb-2 flex gap-2">
          <Button size="sm" onClick={() => setComposing(true)}>
            Compose
          </Button>
          <Button size="sm" variant="secondary" onClick={() => pullMail()} disabled={!mailbox.connected}>
            Pull mail
          </Button>
        </div>
        <ul className="min-h-0 flex-1 space-y-1 overflow-auto">
          {list.map((m) => (
            <li key={m.id}>
              <button
                type="button"
                onClick={() => {
                  selectMail(m.id);
                  markMailRead(m.id);
                  setComposing(false);
                }}
                className={cn(
                  "w-full rounded-md px-3 py-2.5 text-left transition-colors duration-150",
                  selected?.id === m.id ? "bg-raised" : "hover:bg-raised/60",
                  !m.read && "border-l-2 border-l-primary",
                )}
              >
                <p className="truncate text-sm text-fg">{m.subject}</p>
                <p className="truncate text-xs text-muted">{m.from}</p>
                <p className="mt-1 font-mono text-[10px] text-faint">{formatClock(m.at)}</p>
              </button>
            </li>
          ))}
          {list.length === 0 ? (
            <li className="px-3 py-8 text-center text-sm text-muted">Empty folder.</li>
          ) : null}
        </ul>
      </div>

      <div className="min-w-0 flex-1 rounded-lg bg-surface p-4 shadow-panel">
        {composing ? (
          <form
            className="flex flex-col gap-3"
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
          >
            <h2 className="text-sm font-medium">Dispatch email</h2>
            <Input
              placeholder="To"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              autoComplete="off"
            />
            <Input
              placeholder="Subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
            <Textarea
              placeholder="Plan, route, wait, and what changed."
              value={body}
              onChange={(e) => setBody(e.target.value)}
              className="min-h-40"
            />
            <div className="flex gap-2">
              <Button type="submit">Send</Button>
              <Button type="button" variant="ghost" onClick={() => setComposing(false)}>
                Cancel
              </Button>
            </div>
          </form>
        ) : selected ? (
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge>{KIND_LABEL[selected.kind] ?? selected.kind}</Badge>
              <span className="font-mono text-xs text-muted">{formatClock(selected.at)}</span>
            </div>
            <h2 className="mt-2 text-lg font-medium leading-snug">{selected.subject}</h2>
            <p className="mt-1 text-sm text-muted">
              {selected.from} → {selected.to}
            </p>
            <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-fg">{selected.body}</p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button size="sm" onClick={replyTemplate}>
                Reply with plan
              </Button>
              {selected.loadId ? (
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => {
                    selectLoad(selected.loadId!);
                    setView("dispatch");
                  }}
                >
                  Open linked move
                </Button>
              ) : null}
            </div>
          </div>
        ) : (
          <p className="text-sm text-muted">No message selected.</p>
        )}
      </div>
    </div>
  );
}
