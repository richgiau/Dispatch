import { useDispatch } from "@/lib/dispatch/store";
import { driverById } from "@/lib/dispatch/seed";
import { cn } from "@/lib/utils";

function waitFill(wait: number) {
  if (wait > 100) return "var(--color-danger)";
  if (wait > 50) return "var(--color-warn)";
  return "var(--color-ok)";
}

function congStroke(c: number) {
  if (c > 75) return "var(--color-danger)";
  if (c > 40) return "var(--color-warn)";
  return "var(--color-ok)";
}

export function HarborMap() {
  const terminals = useDispatch((s) => s.terminals);
  const corridors = useDispatch((s) => s.corridors);
  const drivers = useDispatch((s) => s.drivers);
  const loads = useDispatch((s) => s.loads);
  const selectedLoadId = useDispatch((s) => s.selectedLoadId);
  const selectLoad = useDispatch((s) => s.selectLoad);
  const selected = loads.find((l) => l.id === selectedLoadId);
  const selectedDriver = driverById(drivers, selected?.driverId ?? null);

  const i710 = corridors.find((c) => c.id === "i710");
  const i110 = corridors.find((c) => c.id === "i110");
  const i405 = corridors.find((c) => c.id === "i405");
  const alameda = corridors.find((c) => c.id === "alameda");

  return (
    <div className="relative overflow-hidden rounded-lg bg-inset shadow-panel">
      <svg viewBox="0 0 100 100" className="block h-auto w-full" role="img" aria-label="San Pedro Bay operations map">
        <rect width="100" height="100" fill="var(--color-inset)" />
        <path
          d="M0 58 C 18 62, 28 70, 40 78 C 52 88, 70 92, 100 86 L 100 100 L 0 100 Z"
          fill="color-mix(in oklab, var(--color-info) 16%, var(--color-inset))"
        />
        <path
          d="M58 78 C 64 74, 78 70, 92 62 L 100 64 L 100 88 C 80 92, 62 88, 52 82 Z"
          fill="color-mix(in oklab, var(--color-info) 22%, var(--color-inset))"
        />

        <path
          d="M46 100 L 44 70 L 42 48 L 40 22 L 38 0"
          fill="none"
          stroke={congStroke(i710?.congestion ?? 50)}
          strokeWidth="1.6"
          opacity="0.85"
        />
        <path
          d="M62 100 L 58 62 L 50 28 L 48 0"
          fill="none"
          stroke={congStroke(i110?.congestion ?? 40)}
          strokeWidth="1.3"
          opacity="0.8"
        />
        <path
          d="M0 52 L 30 50 L 58 48 L 100 46"
          fill="none"
          stroke={congStroke(i405?.congestion ?? 50)}
          strokeWidth="1.2"
          opacity="0.75"
        />
        <path
          d="M40 86 L 42 60 L 44 38 L 46 10"
          fill="none"
          stroke={congStroke(alameda?.congestion ?? 20)}
          strokeWidth="0.9"
          strokeDasharray="1.6 1.1"
          opacity="0.9"
        />

        {terminals.map((tm) => (
          <g key={tm.id}>
            <circle
              cx={tm.x}
              cy={tm.y}
              r={tm.kind === "marine" ? 2.4 : 1.8}
              fill={waitFill(tm.waitMin)}
              opacity="0.95"
            />
            <text
              x={tm.x + 3.1}
              y={tm.y + 1}
              fill="var(--color-fg)"
              fontSize="2.6"
              fontFamily="var(--font-mono)"
            >
              {tm.code}
            </text>
          </g>
        ))}

        {drivers
          .filter((d) => d.status !== "available")
          .map((d) => {
            const isSel = selectedDriver?.id === d.id;
            return (
              <g
                key={d.id}
                className="cursor-pointer"
                onClick={() => d.loadId && selectLoad(d.loadId)}
              >
                <rect
                  x={d.x - 1.4}
                  y={d.y - 1.1}
                  width="2.8"
                  height="2.2"
                  rx="0.35"
                  fill={d.status === "offline" ? "var(--color-danger)" : "var(--color-primary)"}
                  stroke={isSel ? "var(--color-fg)" : "none"}
                  strokeWidth={isSel ? 0.4 : 0}
                />
              </g>
            );
          })}
      </svg>
      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3">
        <p className="rounded-sm bg-bg/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-muted">
          San Pedro Bay
        </p>
        <p className="rounded-sm bg-bg/80 px-2 py-1 font-mono text-[10px] tabular-nums text-muted">
          710 +{i710?.delayMin ?? 0}m
        </p>
      </div>
      <div className="flex flex-wrap gap-3 border-t border-border px-3 py-2 text-[10px] uppercase tracking-wide text-muted">
        <span className="flex items-center gap-1.5">
          <i className="size-2 rounded-full bg-ok" /> Clear
        </span>
        <span className="flex items-center gap-1.5">
          <i className="size-2 rounded-full bg-warn" /> Slow
        </span>
        <span className="flex items-center gap-1.5">
          <i className="size-2 rounded-full bg-danger" /> Severe
        </span>
        <span className="flex items-center gap-1.5">
          <i className={cn("size-2 rounded-sm bg-primary")} /> Unit
        </span>
      </div>
    </div>
  );
}
