import { HarborMap } from "@/components/app/harbor-map";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useDispatch } from "@/lib/dispatch/store";
import { cn } from "@/lib/utils";

export function ConditionsView() {
  const terminals = useDispatch((s) => s.terminals);
  const corridors = useDispatch((s) => s.corridors);
  const injectEvent = useDispatch((s) => s.injectEvent);
  const setView = useDispatch((s) => s.setView);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4 lg:flex-row">
      <div className="flex min-w-0 flex-1 flex-col gap-4">
        <HarborMap />
        <div className="rounded-lg bg-surface p-4 shadow-panel">
          <h2 className="text-sm font-medium">Corridors</h2>
          <ul className="mt-3 space-y-3">
            {corridors.map((c) => (
              <li key={c.id}>
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm text-fg">{c.name}</p>
                  <span className="font-mono text-xs tabular-nums text-muted">+{c.delayMin}m</span>
                </div>
                <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-inset">
                  <div
                    className={cn(
                      "h-full rounded-full transition-[width] duration-300",
                      c.congestion > 75 ? "bg-danger" : c.congestion > 40 ? "bg-warn" : "bg-ok",
                    )}
                    style={{ width: `${c.congestion}%` }}
                  />
                </div>
                <p className="mt-1 text-xs text-muted">{c.note}</p>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="flex w-full flex-col gap-3 lg:w-[380px]">
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" onClick={() => injectEvent("traffic")}>
            Inject traffic event
          </Button>
          <Button size="sm" variant="secondary" onClick={() => injectEvent("terminal-line")}>
            Inject gate issue
          </Button>
          <Button size="sm" variant="outline" onClick={() => setView("planner")}>
            Replan from this
          </Button>
        </div>
        <div className="min-h-0 flex-1 overflow-auto rounded-lg bg-surface shadow-panel">
          <table className="w-full text-left text-sm">
            <thead className="text-[11px] uppercase tracking-wider text-muted">
              <tr>
                <th className="px-3 py-2 font-medium">Terminal</th>
                <th className="px-3 py-2 font-medium">Line</th>
                <th className="px-3 py-2 font-medium">Wait</th>
              </tr>
            </thead>
            <tbody>
              {terminals.map((t) => (
                <tr key={t.id} className="border-t border-border">
                  <td className="px-3 py-2.5">
                    <p className="font-mono text-xs text-primary">{t.code}</p>
                    <p>{t.name}</p>
                    <p className="text-xs text-muted">{t.notes}</p>
                  </td>
                  <td className="px-3 py-2.5">
                    <Badge
                      tone={t.gateStatus === "open" ? "ok" : t.gateStatus === "slow" ? "warn" : "danger"}
                    >
                      {t.gateStatus}
                    </Badge>
                    <p className="mt-1 font-mono text-xs tabular-nums text-muted">{t.lineTrucks} trucks</p>
                  </td>
                  <td className="px-3 py-2.5 font-mono tabular-nums">{t.waitMin}m</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
