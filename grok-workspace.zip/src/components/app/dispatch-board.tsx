import { useMemo, useState } from "react";
import { ArrowRight, Radio } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { HarborMap } from "@/components/app/harbor-map";
import { LiveDot, RiskChip, StatusChip } from "@/components/app/status-chip";
import { driverById, terminalById } from "@/lib/dispatch/seed";
import { useDispatch } from "@/lib/dispatch/store";
import type { LoadStatus } from "@/lib/dispatch/types";
import { cn, etaLabel, formatClock } from "@/lib/utils";

const FILTERS: { id: "all" | LoadStatus; label: string }[] = [
  { id: "all", label: "All" },
  { id: "waiting", label: "Waiting" },
  { id: "en-route", label: "En route" },
  { id: "hold", label: "Hold" },
  { id: "planned", label: "Planned" },
];

export function DispatchBoard() {
  const loads = useDispatch((s) => s.loads);
  const drivers = useDispatch((s) => s.drivers);
  const terminals = useDispatch((s) => s.terminals);
  const selectedLoadId = useDispatch((s) => s.selectedLoadId);
  const selectLoad = useDispatch((s) => s.selectLoad);
  const mc3 = useDispatch((s) => s.mc3);
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");

  const visible = useMemo(() => {
    const list = filter === "all" ? loads : loads.filter((l) => l.status === filter);
    return [...list].sort((a, b) => {
      const rank = { high: 0, medium: 1, low: 2 };
      return rank[a.risk] - rank[b.risk];
    });
  }, [loads, filter]);

  const selected = loads.find((l) => l.id === selectedLoadId) ?? visible[0];
  const kpis = {
    active: loads.filter((l) => l.status !== "complete" && l.status !== "planned").length,
    waiting: loads.filter((l) => l.status === "waiting" || l.status === "at-terminal").length,
    high: loads.filter((l) => l.risk === "high" && l.status !== "complete").length,
    avgWait: Math.round(
      terminals.filter((t) => t.kind === "marine").reduce((a, t) => a + t.waitMin, 0) /
        Math.max(1, terminals.filter((t) => t.kind === "marine").length),
    ),
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-4 lg:flex-row lg:overflow-hidden">
      <div className="flex min-h-0 min-w-0 flex-1 flex-col gap-4 lg:overflow-hidden">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {[
            { k: "Active moves", v: kpis.active },
            { k: "In line", v: kpis.waiting },
            { k: "High risk", v: kpis.high },
            { k: "Avg terminal wait", v: `${kpis.avgWait}m` },
          ].map((x) => (
            <div key={x.k} className="rounded-lg bg-surface p-3 shadow-panel">
              <p className="text-[11px] uppercase tracking-wider text-muted">{x.k}</p>
              <p className="mt-1 font-mono text-xl tabular-nums text-fg">{x.v}</p>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap gap-1.5">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id)}
              className={cn(
                "h-9 rounded-full px-3 text-xs font-medium transition-colors duration-150",
                filter === f.id ? "bg-primary text-primary-fg" : "bg-raised text-muted hover:text-fg",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="min-h-0 flex-1 overflow-auto rounded-lg bg-surface shadow-panel lg:max-h-none">
          <table className="w-full min-w-[640px] text-left text-sm">
            <thead className="bg-surface text-[11px] uppercase tracking-wider text-muted">
              <tr>
                <th className="px-3 py-2 font-medium">Move</th>
                <th className="px-3 py-2 font-medium">Lane</th>
                <th className="px-3 py-2 font-medium">Driver</th>
                <th className="px-3 py-2 font-medium">Wait</th>
                <th className="px-3 py-2 font-medium">ETA</th>
                <th className="px-3 py-2 font-medium">Risk</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((load) => {
                const d = driverById(drivers, load.driverId);
                const o = terminalById(terminals, load.originId);
                const dest = terminalById(terminals, load.destId);
                const active = selected?.id === load.id;
                return (
                  <tr
                    key={load.id}
                    onClick={() => selectLoad(load.id)}
                    className={cn(
                      "cursor-pointer border-t border-border transition-colors duration-150",
                      active ? "bg-raised" : "hover:bg-raised/60",
                    )}
                  >
                    <td className="px-3 py-2.5">
                      <div className="flex flex-col gap-1">
                        <span className="font-mono text-xs text-primary">{load.container}</span>
                        <StatusChip status={load.status} />
                      </div>
                    </td>
                    <td className="px-3 py-2.5">
                      <p className="text-fg">
                        {o?.code} <ArrowRight className="inline size-3 text-faint" /> {dest?.code}
                      </p>
                      <p className="text-xs text-muted">{load.customer}</p>
                    </td>
                    <td className="px-3 py-2.5">
                      <p>{d?.name ?? "Unassigned"}</p>
                      <p className="font-mono text-xs text-muted">{d ? `#${d.truck}` : "—"}</p>
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums">
                      {load.waitMin > 0 ? `${load.waitMin}m` : "—"}
                    </td>
                    <td className="px-3 py-2.5 font-mono tabular-nums text-muted">
                      {load.status === "complete" ? "done" : etaLabel(load.eta)}
                    </td>
                    <td className="px-3 py-2.5">
                      <RiskChip risk={load.risk} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <aside className="flex w-full shrink-0 flex-col gap-3 lg:w-[360px]">
        <HarborMap />
        {selected ? (
          <LoadDetail loadId={selected.id} />
        ) : (
          <div className="rounded-lg bg-surface p-4 text-sm text-muted shadow-panel">
            Select a move.
          </div>
        )}
        <div className="hidden items-center justify-between rounded-lg bg-surface px-3 py-2 text-xs shadow-panel lg:flex">
          <LiveDot on={mc3.connected} />
          <span className="font-mono text-muted">
            {mc3.lastSync ? formatClock(mc3.lastSync) : "no sync"}
          </span>
        </div>
      </aside>
    </div>
  );
}

function LoadDetail({ loadId }: { loadId: string }) {
  const load = useDispatch((s) => s.loads.find((l) => l.id === loadId));
  const drivers = useDispatch((s) => s.drivers);
  const terminals = useDispatch((s) => s.terminals);
  const assignDriver = useDispatch((s) => s.assignDriver);
  const updateLoadRoute = useDispatch((s) => s.updateLoadRoute);
  const setLoadStatus = useDispatch((s) => s.setLoadStatus);
  const setView = useDispatch((s) => s.setView);
  if (!load) return null;
  const driver = driverById(drivers, load.driverId);
  const origin = terminalById(terminals, load.originId);
  const dest = terminalById(terminals, load.destId);
  const free = drivers.filter((d) => d.status === "available" || d.id === load.driverId);

  return (
    <div className="rounded-lg bg-surface p-4 shadow-panel">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-mono text-xs text-primary">{load.mc3MoveId}</p>
          <h2 className="text-base font-medium text-fg">{load.container}</h2>
          <p className="text-sm text-muted">
            {load.size} · {load.type} · {load.ssl}
          </p>
        </div>
        <StatusChip status={load.status} />
      </div>

      <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <div>
          <dt className="text-[11px] uppercase tracking-wider text-muted">From</dt>
          <dd>
            {origin?.name}
            <span className="block text-xs text-muted">{origin?.waitMin}m wait</span>
          </dd>
        </div>
        <div>
          <dt className="text-[11px] uppercase tracking-wider text-muted">To</dt>
          <dd>
            {dest?.name}
            <span className="block text-xs text-muted">{load.customer}</span>
          </dd>
        </div>
      </dl>

      <p className="mt-3 text-sm text-fg">{load.route}</p>
      {load.altRoute ? (
        <p className="mt-1 text-xs text-muted">Alt: {load.altRoute}</p>
      ) : null}
      <p className="mt-2 text-sm text-muted">{load.notes}</p>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {load.legs.map((leg) => (
          <Badge key={leg.id} tone={leg.status === "done" ? "ok" : leg.status === "active" ? "primary" : "muted"}>
            {leg.sequence}. {leg.action}
            {leg.appointment ? ` · ${leg.appointment}` : ""}
          </Badge>
        ))}
      </div>

      <label className="mt-4 block text-[11px] uppercase tracking-wider text-muted">
        Assign driver
        <select
          className="mt-1 h-11 w-full rounded-sm border border-border bg-inset px-3 text-sm text-fg"
          value={load.driverId ?? ""}
          onChange={(e) => {
            if (e.target.value) assignDriver(load.id, e.target.value);
          }}
        >
          <option value="">Unassigned</option>
          {free.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name} · #{d.truck} · HOS {Math.round(d.hosRemainMin / 60)}h
            </option>
          ))}
        </select>
      </label>

      {driver ? (
        <p className="mt-2 flex items-center gap-2 text-xs text-muted">
          <Radio className="size-3" />
          {driver.locationLabel} · {driver.mc3Online ? "pinged" : "stale"}
        </p>
      ) : null}

      <div className="mt-3 flex flex-wrap gap-2">
        {load.altRoute ? (
          <Button
            size="sm"
            variant="secondary"
            onClick={() => updateLoadRoute(load.id, load.altRoute)}
          >
            Switch to alt route
          </Button>
        ) : null}
        {load.status !== "hold" ? (
          <Button size="sm" variant="outline" onClick={() => setLoadStatus(load.id, "hold")}>
            Hold
          </Button>
        ) : (
          <Button size="sm" variant="outline" onClick={() => setLoadStatus(load.id, "dispatched")}>
            Release
          </Button>
        )}
        <Button size="sm" variant="ghost" onClick={() => setView("planner")}>
          Ask planner
        </Button>
      </div>
    </div>
  );
}
