import { Badge } from "@/components/ui/badge";
import { LiveDot, StatusChip } from "@/components/app/status-chip";
import { useDispatch } from "@/lib/dispatch/store";
import { formatMinutes } from "@/lib/utils";

export function FleetView() {
  const drivers = useDispatch((s) => s.drivers);
  const loads = useDispatch((s) => s.loads);
  const mc3 = useDispatch((s) => s.mc3);
  const selectLoad = useDispatch((s) => s.selectLoad);
  const setView = useDispatch((s) => s.setView);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium">MC3 units</h2>
        <LiveDot on={mc3.connected} />
      </div>
      <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
        {drivers.map((d) => {
          const load = loads.find((l) => l.id === d.loadId);
          return (
            <button
              key={d.id}
              type="button"
              onClick={() => {
                if (load) {
                  selectLoad(load.id);
                  setView("dispatch");
                }
              }}
              className="rounded-lg bg-surface p-4 text-left shadow-panel transition-colors duration-150 hover:bg-raised"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-medium">{d.name}</p>
                  <p className="font-mono text-xs text-muted">Truck {d.truck}</p>
                </div>
                <StatusChip status={d.status} />
              </div>
              <p className="mt-3 text-sm text-fg">{d.locationLabel}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <Badge tone={d.mc3Online ? "ok" : "danger"}>
                  {d.mc3Online ? "GPS" : "stale"}
                </Badge>
                <Badge tone={d.hosRemainMin < 60 ? "danger" : "muted"}>
                  HOS {formatMinutes(d.hosRemainMin)}
                </Badge>
                {d.chassis ? <Badge tone="info">{d.chassis}</Badge> : <Badge>no chassis</Badge>}
              </div>
              <p className="mt-2 font-mono text-xs text-primary">
                {load ? load.container : "No move"}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
}
