import { useState } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LiveDot } from "@/components/app/status-chip";
import { useDispatch } from "@/lib/dispatch/store";
import { formatClock } from "@/lib/utils";

export function SettingsView() {
  const mc3 = useDispatch((s) => s.mc3);
  const mailbox = useDispatch((s) => s.mailbox);
  const syncLog = useDispatch((s) => s.syncLog);
  const connectMc3 = useDispatch((s) => s.connectMc3);
  const disconnectMc3 = useDispatch((s) => s.disconnectMc3);
  const syncMc3 = useDispatch((s) => s.syncMc3);
  const connectMailbox = useDispatch((s) => s.connectMailbox);
  const disconnectMailbox = useDispatch((s) => s.disconnectMailbox);
  const setAutoPush = useDispatch((s) => s.setAutoPush);
  const resetDemo = useDispatch((s) => s.resetDemo);

  const [tenant, setTenant] = useState(mc3.tenant);
  const [key, setKey] = useState("");
  const [env, setEnv] = useState<"sandbox" | "production">(mc3.environment);
  const [address, setAddress] = useState(mailbox.address);

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
      <section className="rounded-lg bg-surface p-4 shadow-panel">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-medium">Trinium MC3</h2>
          <LiveDot on={mc3.connected} />
        </div>
        <p className="mt-1 text-sm text-muted">
          Link the driver app and TMS tenant used by this fleet. Pierline pulls GPS, geofence legs, and move status, then pushes assignment and route changes back to MC3.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <label className="text-xs text-muted">
            Tenant host
            <Input
              className="mt-1"
              value={tenant}
              onChange={(e) => setTenant(e.target.value)}
              placeholder="pacificgate.trinium.cloud"
            />
          </label>
          <label className="text-xs text-muted">
            Integration key
            <Input
              className="mt-1"
              type="password"
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="MC3 API key"
              autoComplete="off"
            />
          </label>
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <select
            className="h-11 rounded-sm border border-border bg-inset px-3 text-sm"
            value={env}
            onChange={(e) => setEnv(e.target.value as "sandbox" | "production")}
          >
            <option value="sandbox">Sandbox</option>
            <option value="production">Production</option>
          </select>
          {mc3.connected ? (
            <>
              <Button variant="secondary" onClick={() => syncMc3()}>
                Sync now
              </Button>
              <Button variant="outline" onClick={() => disconnectMc3()}>
                Disconnect
              </Button>
            </>
          ) : (
            <Button
              onClick={() => {
                connectMc3(tenant, key || "sandbox-demo-key", env);
                const err = useDispatch.getState().mc3.lastError;
                if (err) toast.error(err);
                else toast.success("MC3 linked. GPS and legs are live.");
              }}
            >
              Connect MC3
            </Button>
          )}
        </div>
        {mc3.lastError ? <p className="mt-2 text-sm text-danger">{mc3.lastError}</p> : null}
        <label className="mt-4 flex min-h-11 items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={mc3.autoPush}
            onChange={(e) => setAutoPush(e.target.checked)}
            className="size-4 accent-primary"
          />
          Push accepted plan changes to MC3 automatically
        </label>
        <p className="mt-2 font-mono text-xs text-muted">
          Last sync {mc3.lastSync ? formatClock(mc3.lastSync) : "never"} · last push{" "}
          {mc3.lastPush ? formatClock(mc3.lastPush) : "none"}
        </p>
      </section>

      <section className="rounded-lg bg-surface p-4 shadow-panel">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-medium">Dispatch mailbox</h2>
          <Badge tone={mailbox.connected ? "ok" : "muted"}>
            {mailbox.connected ? "linked" : "local"}
          </Badge>
        </div>
        <p className="mt-1 text-sm text-muted">
          Inbound tenders, terminal advisories, and driver exception mail. Outbound plan changes go to drivers and customers.
        </p>
        <label className="mt-4 block text-xs text-muted">
          Address
          <Input
            className="mt-1"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
          />
        </label>
        <div className="mt-3 flex flex-wrap gap-2">
          {mailbox.connected ? (
            <Button variant="outline" onClick={() => disconnectMailbox()}>
              Disconnect
            </Button>
          ) : (
            <Button
              onClick={() => {
                connectMailbox(address);
                toast.success("Mailbox linked.");
              }}
            >
              Link mailbox
            </Button>
          )}
        </div>
      </section>

      <section className="rounded-lg bg-surface p-4 shadow-panel">
        <h2 className="text-sm font-medium">Integration log</h2>
        <ul className="mt-3 max-h-56 space-y-2 overflow-auto font-mono text-xs text-muted">
          {syncLog.map((e) => (
            <li key={e.id}>
              <span className="text-faint">{formatClock(e.at)}</span>{" "}
              <span className="text-primary">{e.direction === "in" ? "IN" : "OUT"}</span> {e.message}
            </li>
          ))}
        </ul>
        <Button
          className="mt-4"
          size="sm"
          variant="ghost"
          onClick={() => {
            resetDemo();
            toast.message("Demo board restored.");
          }}
        >
          Reset demo board
        </Button>
      </section>
    </div>
  );
}
