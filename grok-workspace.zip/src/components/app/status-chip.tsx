import { Badge } from "@/components/ui/badge";
import { STATUS_LABEL } from "@/lib/dispatch/seed";
import type { LoadStatus } from "@/lib/dispatch/types";

const loadTone: Record<LoadStatus, "muted" | "primary" | "ok" | "warn" | "danger" | "info"> = {
  planned: "muted",
  dispatched: "info",
  "at-terminal": "primary",
  waiting: "warn",
  "en-route": "info",
  "at-customer": "primary",
  complete: "ok",
  hold: "danger",
};

const riskTone = {
  low: "ok" as const,
  medium: "warn" as const,
  high: "danger" as const,
};

export function StatusChip({ status }: { status: LoadStatus | string }) {
  const tone = (loadTone as Record<string, "muted" | "primary" | "ok" | "warn" | "danger" | "info">)[
    status
  ] ?? "muted";
  return <Badge tone={tone}>{STATUS_LABEL[status] ?? status}</Badge>;
}

export function RiskChip({ risk }: { risk: "low" | "medium" | "high" }) {
  return <Badge tone={riskTone[risk]}>{risk}</Badge>;
}

export function LiveDot({ on }: { on: boolean }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted">
      <span
        className={`size-1.5 rounded-full ${on ? "bg-ok live-dot" : "bg-faint"}`}
      />
      {on ? "MC3 live" : "MC3 idle"}
    </span>
  );
}
