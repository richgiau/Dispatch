import type { ReactNode } from "react";
import { Toaster } from "sonner";

export function AuthProvider({ children }: { children: ReactNode }) {
  return (
    <>
      {children}
      <Toaster
        theme="dark"
        position="bottom-right"
        toastOptions={{
          className:
            "!bg-surface !text-fg !border !border-border !font-[family-name:var(--font-sans)]",
        }}
      />
    </>
  );
}
