export type ViewId =
  | "dispatch"
  | "conditions"
  | "fleet"
  | "events"
  | "mail"
  | "planner"
  | "settings";

export type LoadStatus =
  | "planned"
  | "dispatched"
  | "at-terminal"
  | "waiting"
  | "en-route"
  | "at-customer"
  | "complete"
  | "hold";

export type EventSeverity = "info" | "watch" | "critical";

export type EventKind =
  | "traffic"
  | "terminal-line"
  | "wait-time"
  | "breakdown"
  | "weather"
  | "vessel"
  | "chassis"
  | "hos"
  | "appointment"
  | "other";

export type MailFolder = "inbox" | "sent" | "drafts";

export type RecoType =
  | "reroute"
  | "reassign"
  | "hold"
  | "release"
  | "appointment"
  | "email";

export type Terminal = {
  id: string;
  name: string;
  code: string;
  kind: "marine" | "rail" | "yard" | "customer";
  x: number;
  y: number;
  waitMin: number;
  lineTrucks: number;
  gateStatus: "open" | "slow" | "hold";
  notes: string;
};

export type Corridor = {
  id: string;
  name: string;
  congestion: number;
  delayMin: number;
  status: "clear" | "slow" | "closed";
  note: string;
};

export type Driver = {
  id: string;
  name: string;
  truck: string;
  phone: string;
  email: string;
  status: "available" | "assigned" | "waiting" | "driving" | "offline";
  hosRemainMin: number;
  chassis: string | null;
  locationLabel: string;
  x: number;
  y: number;
  heading: number;
  loadId: string | null;
  mc3Online: boolean;
  lastPing: number;
};

export type Leg = {
  id: string;
  sequence: number;
  action: "pickup" | "deliver" | "return" | "live-load" | "drop";
  locationId: string;
  appointment?: string;
  windowStart?: number;
  windowEnd?: number;
  status: "pending" | "active" | "done" | "skipped";
};

export type Load = {
  id: string;
  container: string;
  size: "20" | "40" | "40HC" | "45";
  type: "import" | "export" | "street-turn";
  customer: string;
  ssl: string;
  booking: string;
  status: LoadStatus;
  driverId: string | null;
  originId: string;
  destId: string;
  route: string;
  altRoute: string;
  eta: number;
  risk: "low" | "medium" | "high";
  waitMin: number;
  legs: Leg[];
  notes: string;
  mc3MoveId: string;
};

export type OpsEvent = {
  id: string;
  kind: EventKind;
  severity: EventSeverity;
  title: string;
  detail: string;
  at: number;
  loadId?: string;
  driverId?: string;
  terminalId?: string;
  corridorId?: string;
  acknowledged: boolean;
};

export type MailMessage = {
  id: string;
  folder: MailFolder;
  from: string;
  to: string;
  subject: string;
  body: string;
  at: number;
  read: boolean;
  loadId?: string;
  driverId?: string;
  kind: "tender" | "advisory" | "driver" | "customer" | "plan";
};

export type Recommendation = {
  id: string;
  type: RecoType;
  title: string;
  rationale: string;
  loadId?: string;
  driverId?: string;
  newRoute?: string;
  newDriverId?: string;
  newStatus?: LoadStatus;
  holdMinutes?: number;
  minutesSaved: number;
  emailDraft?: { to: string; subject: string; body: string };
  status: "proposed" | "applied" | "dismissed";
};

export type PlanRun = {
  id: string;
  at: number;
  summary: string;
  riskLevel: "stable" | "elevated" | "severe";
  recommendations: Recommendation[];
};

export type Mc3Connection = {
  connected: boolean;
  tenant: string;
  apiKeySet: boolean;
  environment: "sandbox" | "production";
  lastSync: number | null;
  lastPush: number | null;
  lastError: string | null;
  autoPush: boolean;
};

export type MailboxConnection = {
  connected: boolean;
  address: string;
  lastPull: number | null;
};

export type SyncLogEntry = {
  id: string;
  at: number;
  direction: "in" | "out";
  message: string;
};

export type DispatchState = {
  company: string;
  shiftStart: number;
  view: ViewId;
  selectedLoadId: string | null;
  selectedMailId: string | null;
  terminals: Terminal[];
  corridors: Corridor[];
  drivers: Driver[];
  loads: Load[];
  events: OpsEvent[];
  mail: MailMessage[];
  plans: PlanRun[];
  mc3: Mc3Connection;
  mailbox: MailboxConnection;
  syncLog: SyncLogEntry[];
  tick: number;
};
