import { createServerFn } from "@tanstack/react-start";
import type { PlanRun, Recommendation } from "./types";

type PlannerInput = {
  snapshot: unknown;
  question?: string;
};

function parsePlan(text: string, snapshot: unknown): PlanRun {
  const jsonStart = text.indexOf("{");
  const jsonEnd = text.lastIndexOf("}");
  const raw = jsonStart >= 0 ? text.slice(jsonStart, jsonEnd + 1) : text;
  let parsed: {
    summary?: string;
    riskLevel?: PlanRun["riskLevel"];
    recommendations?: Array<Partial<Recommendation> & { emailDraft?: Recommendation["emailDraft"] }>;
  } = {};
  try {
    parsed = JSON.parse(raw) as typeof parsed;
  } catch {
    parsed = {
      summary: text.slice(0, 800),
      riskLevel: "elevated",
      recommendations: [],
    };
  }
  const recs = (parsed.recommendations ?? []).slice(0, 8).map((r, i) => {
    const id = r.id && typeof r.id === "string" ? r.id : `rec-${i + 1}`;
    return {
      id,
      type: (r.type as Recommendation["type"]) || "reroute",
      title: String(r.title ?? "Adjustment"),
      rationale: String(r.rationale ?? ""),
      loadId: r.loadId,
      driverId: r.driverId,
      newRoute: r.newRoute,
      newDriverId: r.newDriverId,
      newStatus: r.newStatus,
      holdMinutes: r.holdMinutes,
      minutesSaved: Number(r.minutesSaved ?? 0) || 0,
      emailDraft: r.emailDraft,
      status: "proposed" as const,
    } satisfies Recommendation;
  });
  void snapshot;
  return {
    id: `plan-${Date.now()}`,
    at: Date.now(),
    summary: String(parsed.summary ?? "Plan generated."),
    riskLevel: parsed.riskLevel === "severe" || parsed.riskLevel === "stable" ? parsed.riskLevel : "elevated",
    recommendations: recs,
  };
}

export const runDispatchPlan = createServerFn({ method: "POST" })
  .validator((input: PlannerInput) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "AI dispatch is not available in this environment." };
    }

    const question =
      data.question?.trim() ||
      "Replan the board from current traffic, terminal lines, waiting time, HOS, chassis, and unplanned events. Change routing and assignments only where it saves time or prevents a missed window.";

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.3,
        max_tokens: 1600,
        response_format: { type: "json_object" },
        messages: [
          {
            role: "system",
            content: `You are Pierline, an AI dispatch engine for container drayage in San Pedro Bay (Los Angeles / Long Beach). The fleet runs on Trinium TMS with the MC3 driver app. You plan and replan moves using terminal wait times, gate lines, highway traffic, chassis pools, hours of service, appointments, and unplanned events.

Rules:
- Prefer concrete actions: reroute, reassign, hold, release, appointment shift, or email the driver/customer.
- Use only IDs present in the snapshot (load ids like mv-1044, driver ids like d-reyes).
- For reroutes, put the full new path in newRoute (e.g. "LBCT → I-605 → SR-60 → Ontario").
- For reassign, set newDriverId to an available driver id.
- minutesSaved must be a realistic integer.
- Include an emailDraft when a driver or customer must be told (to, subject, body). Use the emails in the snapshot.
- Do not invent terminals or trucks.
- 4 to 7 recommendations. Highest impact first.
- JSON only with shape:
{
  "summary": string,
  "riskLevel": "stable" | "elevated" | "severe",
  "recommendations": [{
    "id": string,
    "type": "reroute" | "reassign" | "hold" | "release" | "appointment" | "email",
    "title": string,
    "rationale": string,
    "loadId": string,
    "driverId": string,
    "newRoute": string,
    "newDriverId": string,
    "newStatus": "planned" | "dispatched" | "hold" | "en-route",
    "holdMinutes": number,
    "minutesSaved": number,
    "emailDraft": { "to": string, "subject": string, "body": string }
  }]
}`,
          },
          {
            role: "user",
            content: `${question}\n\nSNAPSHOT:\n${JSON.stringify(data.snapshot)}`,
          },
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false as const, error: `xAI API error ${res.status}` };
    }
    const body = (await res.json()) as {
      choices: { message: { content: string } }[];
    };
    const text = body.choices[0]?.message.content ?? "";
    return { ok: true as const, plan: parsePlan(text, data.snapshot) };
  });

export const askDispatchAi = createServerFn({ method: "POST" })
  .validator((input: PlannerInput) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "AI dispatch is not available in this environment." };
    }
    const q = data.question?.trim();
    if (!q) return { ok: false as const, error: "Ask a dispatch question first." };

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.2,
        max_tokens: 700,
        messages: [
          {
            role: "system",
            content:
              "You are Pierline, a concise harbor dispatch assistant for Trinium MC3 drayage. Answer in 1–3 short paragraphs plus a bullet list of actions if needed. Use the snapshot. No markdown tables. No fluff.",
          },
          {
            role: "user",
            content: `${q}\n\nSNAPSHOT:\n${JSON.stringify(data.snapshot)}`,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: `xAI API error ${res.status}` };
    const body = (await res.json()) as {
      choices: { message: { content: string } }[];
    };
    return { ok: true as const, text: body.choices[0]?.message.content ?? "" };
  });
