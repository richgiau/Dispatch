import type { DispatchState, PlanRun, Recommendation } from "./types";
import { driverById, terminalById } from "./seed";

function rec(partial: Omit<Recommendation, "status">): Recommendation {
  return { ...partial, status: "proposed" };
}

export function localReplan(state: DispatchState): PlanRun {
  const recs: Recommendation[] = [];
  const i710 = state.corridors.find((c) => c.id === "i710");
  const apm = terminalById(state.terminals, "apm");
  const available = state.drivers.filter((d) => d.status === "available");
  const rescue = available.find((d) => d.hosRemainMin > 180) ?? available[0];

  const chen = state.loads.find((l) => l.id === "mv-1051");
  if (chen && i710 && i710.delayMin >= 15) {
    recs.push(
      rec({
        id: "rec-710",
        type: "reroute",
        title: "Pull Chen off I-710 before the 405 blockage",
        rationale: `I-710 is +${i710.delayMin} min with ${i710.congestion}% congestion. ${chen.altRoute}`,
        loadId: chen.id,
        driverId: chen.driverId ?? undefined,
        newRoute: chen.altRoute,
        minutesSaved: i710.delayMin,
        emailDraft: {
          to: "mchen@pgdray.ops",
          subject: "MC3 reroute — leave 710, take 110 / 47",
          body: `Mei, 710 NB is blocked at the 405. Exit and take the Harbor / Alameda. Still delivering ${chen.container} to Carson. Confirm on MC3 when you turn.`,
        },
      }),
    );
  }

  const vasquez = state.loads.find((l) => l.id === "mv-1044");
  if (vasquez && apm && apm.waitMin >= 90) {
    recs.push(
      rec({
        id: "rec-apm",
        type: "reroute",
        title: "Break the APM dual — Alameda out-gate when wheels clear",
        rationale: `APM line ${apm.lineTrucks} trucks / ${apm.waitMin}m wait. Staying for the dual blows the Vernon 21:00 window.`,
        loadId: vasquez.id,
        driverId: vasquez.driverId ?? undefined,
        newRoute: vasquez.altRoute,
        minutesSaved: Math.max(20, apm.waitMin - 70),
        emailDraft: {
          to: "rvasquez@pgdray.ops",
          subject: "MC3 — drop the dual, run Alameda to Vernon",
          body: `Rafael, cancel the dual at APM. Out-gate as soon as you have the box and run Alameda to I-110. Harbor Foods cutoff 21:00.`,
        },
      }),
    );
  }

  const second = state.loads.find((l) => l.id === "mv-1077");
  if (second && apm && apm.waitMin >= 90 && rescue) {
    recs.push(
      rec({
        id: "rec-hold-apm",
        type: "hold",
        title: `Hold ${second.container} until APM duals clear`,
        rationale: "Do not send a second truck into a 2-hour line. Stage at the yard and release after 20:00 night duals.",
        loadId: second.id,
        newStatus: "hold",
        holdMinutes: 90,
        minutesSaved: apm.waitMin,
        newDriverId: undefined,
      }),
    );
  }

  const broken = state.loads.find((l) => l.id === "mv-1041");
  const walsh = driverById(state.drivers, "d-walsh");
  if (broken && walsh && walsh.status === "offline" && rescue) {
    recs.push(
      rec({
        id: "rec-rescue",
        type: "reassign",
        title: `Rescue ${broken.container} with truck ${rescue.truck}`,
        rationale: `${walsh.name} is stale on MC3 (air leak, I-405). ${rescue.name} is available with ${Math.round(rescue.hosRemainMin / 60)}h HOS.`,
        loadId: broken.id,
        driverId: walsh.id,
        newDriverId: rescue.id,
        newStatus: "dispatched",
        minutesSaved: 40,
        emailDraft: {
          to: rescue.email,
          subject: `MC3 rescue — ${broken.container} on 405`,
          body: `${rescue.name}, pick up Walsh on I-405 NB Wilmington. Take the 20' Metro Chem box to Carson. Confirm geofence on MC3 when you hook.`,
        },
      }),
    );
  }

  const brooks = state.loads.find((l) => l.id === "mv-1049");
  const brooksDriver = driverById(state.drivers, brooks?.driverId ?? null);
  const night = available.find((d) => d.id !== rescue?.id && d.hosRemainMin > 240);
  if (brooks && brooksDriver && brooksDriver.hosRemainMin < 90) {
    if (night) {
      recs.push(
        rec({
          id: "rec-hos",
          type: "reassign",
          title: `Flip Inland Paper 45' to ${night.name} — Brooks is out of hours`,
          rationale: `${brooksDriver.name} has ${Math.round(brooksDriver.hosRemainMin)} min HOS. Ontario is still ~90 minutes.`,
          loadId: brooks.id,
          driverId: brooksDriver.id,
          newDriverId: night.id,
          newStatus: "dispatched",
          newRoute: "Yard drop → night driver → I-605 → Ontario",
          minutesSaved: 0,
          emailDraft: {
            to: `${brooksDriver.email}, ${night.email}`,
            subject: "MC3 HOS flip — ONEU 2291045",
            body: `${brooksDriver.name}: drop at Pacific Gate Yard, do not start the inland. ${night.name}: hook the 45' and run 605 to Ontario. Window 21:30–22:30.`,
          },
        }),
      );
    } else {
      recs.push(
        rec({
          id: "rec-hos-hold",
          type: "hold",
          title: "Drop Brooks at yard — no legal inland finish",
          rationale: "HOS remaining cannot cover Ontario. Hold the 45' overnight rather than a violation.",
          loadId: brooks.id,
          driverId: brooksDriver.id,
          newStatus: "hold",
          newRoute: brooks.altRoute,
          minutesSaved: 0,
        }),
      );
    }
  }

  const pct = terminalById(state.terminals, "pct");
  const exportPct = state.loads.find((l) => l.id === "mv-1070");
  if (pct && pct.waitMin >= 70 && exportPct) {
    recs.push(
      rec({
        id: "rec-pct",
        type: "appointment",
        title: "Stage the Hapag export if PCT chassis is still short",
        rationale: pct.notes,
        loadId: exportPct.id,
        driverId: exportPct.driverId ?? undefined,
        newRoute: "Ontario → I-605 SB → yard stage if no wheels → PCT when pool opens",
        minutesSaved: 15,
      }),
    );
  }

  const ictf = terminalById(state.terminals, "ictf");
  const rail = state.loads.find((l) => l.id === "mv-1066");
  if (ictf && rail && /late/i.test(ictf.notes)) {
    recs.push(
      rec({
        id: "rec-ictf",
        type: "hold",
        title: "Keep Alvarez in the ICTF gate — do not add more ramp pickups",
        rationale: ictf.notes,
        loadId: rail.id,
        driverId: rail.driverId ?? undefined,
        minutesSaved: 0,
        emailDraft: {
          to: "palvarez@pgdray.ops",
          subject: "ICTF stack train late — stay in gate",
          body: "Priya, UP is 90 late. Stay in the ICTF gate; we are not sending another truck. Update MC3 when the lift starts.",
        },
      }),
    );
  }

  const openCritical = state.events.filter((e) => !e.acknowledged && e.severity === "critical");
  const riskLevel: PlanRun["riskLevel"] =
    openCritical.length >= 3 || (apm && apm.waitMin > 120 && i710 && i710.delayMin > 25)
      ? "severe"
      : openCritical.length > 0
        ? "elevated"
        : "stable";

  return {
    id: `plan-local-${Date.now()}`,
    at: Date.now(),
    summary:
      recs.length > 0
        ? `Harbor conditions require ${recs.length} changes: ${recs.map((r) => r.title).join("; ")}.`
        : "No forced changes. Keep current MC3 assignments and watch 710 plus APM duals.",
    riskLevel,
    recommendations: recs.slice(0, 7),
  };
}
