import { create } from "zustand";
import { persist } from "zustand/middleware";
import { createInitialState, driverById, terminalById } from "./seed";
import type {
  Corridor,
  DispatchState,
  Load,
  LoadStatus,
  MailMessage,
  PlanRun,
  Recommendation,
  Terminal,
  ViewId,
} from "./types";

type Actions = {
  setView: (view: ViewId) => void;
  selectLoad: (id: string | null) => void;
  selectMail: (id: string | null) => void;
  connectMc3: (tenant: string, apiKey: string, environment: "sandbox" | "production") => void;
  disconnectMc3: () => void;
  syncMc3: () => void;
  connectMailbox: (address: string) => void;
  disconnectMailbox: () => void;
  pullMail: () => void;
  markMailRead: (id: string) => void;
  sendMail: (msg: Omit<MailMessage, "id" | "at" | "read" | "folder" | "from">) => void;
  acknowledgeEvent: (id: string) => void;
  injectEvent: (kind: "traffic" | "terminal-line" | "weather" | "chassis") => void;
  assignDriver: (loadId: string, driverId: string) => void;
  updateLoadRoute: (loadId: string, route: string) => void;
  setLoadStatus: (loadId: string, status: LoadStatus) => void;
  applyRecommendation: (planId: string, recoId: string) => void;
  dismissRecommendation: (planId: string, recoId: string) => void;
  applyAllRecommendations: (planId: string) => void;
  addPlan: (plan: PlanRun) => void;
  tickSim: () => void;
  resetDemo: () => void;
  setAutoPush: (value: boolean) => void;
};

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}

function log(
  state: DispatchState,
  direction: "in" | "out",
  message: string,
): DispatchState["syncLog"] {
  return [
    { id: uid("log"), at: Date.now(), direction, message },
    ...state.syncLog,
  ].slice(0, 40);
}

function applyRecoToState(state: DispatchState, reco: Recommendation): DispatchState {
  let next: DispatchState = { ...state };
  const t = Date.now();

  if (reco.loadId && reco.newRoute) {
    next.loads = next.loads.map((l) =>
      l.id === reco.loadId ? { ...l, route: reco.newRoute!, risk: "medium" } : l,
    );
  }
  if (reco.loadId && reco.newStatus) {
    next.loads = next.loads.map((l) =>
      l.id === reco.loadId ? { ...l, status: reco.newStatus! } : l,
    );
  }
  if (reco.loadId && reco.newDriverId) {
    const prev = next.loads.find((l) => l.id === reco.loadId);
    next.drivers = next.drivers.map((d) => {
      if (d.id === prev?.driverId) {
        return { ...d, loadId: null, status: "available" as const };
      }
      if (d.id === reco.newDriverId) {
        const loc = next.loads.find((l) => l.id === reco.loadId);
        const term = loc ? terminalById(next.terminals, loc.originId) : undefined;
        return {
          ...d,
          loadId: reco.loadId!,
          status: "assigned" as const,
          locationLabel: term ? `Assigned · ${term.code}` : "Assigned",
        };
      }
      return d;
    });
    next.loads = next.loads.map((l) =>
      l.id === reco.loadId ? { ...l, driverId: reco.newDriverId!, status: "dispatched" } : l,
    );
  }
  if (reco.emailDraft) {
    next.mail = [
      {
        id: uid("m"),
        folder: "drafts",
        from: next.mailbox.address,
        to: reco.emailDraft.to,
        subject: reco.emailDraft.subject,
        body: reco.emailDraft.body,
        at: t,
        read: true,
        loadId: reco.loadId,
        driverId: reco.driverId,
        kind: "plan",
      },
      ...next.mail,
    ];
  }
  if (next.mc3.connected && next.mc3.autoPush && reco.loadId) {
    const load = next.loads.find((l) => l.id === reco.loadId);
    next.mc3 = { ...next.mc3, lastPush: t };
    next.syncLog = log(
      next,
      "out",
      `MC3 assignment ${load?.mc3MoveId ?? reco.loadId}: ${reco.title}`,
    );
  }
  return next;
}

export const useDispatch = create<DispatchState & Actions>()(
  persist(
    (set, get) => ({
      ...createInitialState(),

      setView: (view) => set({ view }),
      selectLoad: (id) => set({ selectedLoadId: id }),
      selectMail: (id) => set({ selectedMailId: id }),
      setAutoPush: (autoPush) =>
        set((s) => ({ mc3: { ...s.mc3, autoPush } })),

      connectMc3: (tenant, apiKey, environment) => {
        if (apiKey.trim().length < 8) {
          set((s) => ({
            mc3: {
              ...s.mc3,
              lastError: "MC3 key must be at least 8 characters.",
            },
          }));
          return;
        }
        const t = Date.now();
        set((s) => ({
          mc3: {
            connected: true,
            tenant: tenant.trim() || "pacificgate.trinium.cloud",
            apiKeySet: true,
            environment,
            lastSync: t,
            lastPush: null,
            lastError: null,
            autoPush: s.mc3.autoPush,
          },
          drivers: s.drivers.map((d) => ({
            ...d,
            mc3Online: d.status !== "offline",
            lastPing: d.status === "offline" ? d.lastPing : t,
          })),
          syncLog: log(
            s,
            "in",
            `Connected ${environment} tenant ${tenant}. Pulled ${s.drivers.length} units, ${s.loads.length} moves.`,
          ),
        }));
      },

      disconnectMc3: () =>
        set((s) => ({
          mc3: {
            ...s.mc3,
            connected: false,
            lastError: null,
          },
          syncLog: log(s, "out", "MC3 session closed."),
        })),

      syncMc3: () => {
        const s = get();
        if (!s.mc3.connected) return;
        const t = Date.now();
        const online = s.drivers.filter((d) => d.mc3Online).length;
        set({
          mc3: { ...s.mc3, lastSync: t, lastError: null },
          drivers: s.drivers.map((d) =>
            d.status === "offline" ? d : { ...d, lastPing: t - Math.random() * 12000 },
          ),
          syncLog: log(
            s,
            "in",
            `Heartbeat ${online} MC3 units. GPS + geofence legs refreshed.`,
          ),
        });
      },

      connectMailbox: (address) => {
        const addr = address.trim();
        if (!addr.includes("@")) return;
        const t = Date.now();
        set((s) => ({
          mailbox: { connected: true, address: addr, lastPull: t },
          syncLog: log(s, "in", `Mailbox linked: ${addr}. Pulled ${s.mail.filter((m) => m.folder === "inbox").length} inbound.`),
        }));
      },

      disconnectMailbox: () =>
        set((s) => ({
          mailbox: { ...s.mailbox, connected: false },
        })),

      pullMail: () => {
        const s = get();
        if (!s.mailbox.connected) return;
        const t = Date.now();
        const advisory: MailMessage = {
          id: uid("m"),
          folder: "inbox",
          from: "chp-alerts@dot.ca.gov",
          to: s.mailbox.address,
          subject: "Traffic pulse — harbor corridors",
          body: `I-710 delay ${s.corridors.find((c) => c.id === "i710")?.delayMin ?? 0} min. APM wait ${s.terminals.find((t) => t.id === "apm")?.waitMin ?? 0} min. Generated from the latest corridor scan.`,
          at: t,
          read: false,
          kind: "advisory",
        };
        set({
          mailbox: { ...s.mailbox, lastPull: t },
          mail: [advisory, ...s.mail],
        });
      },

      markMailRead: (id) =>
        set((s) => ({
          mail: s.mail.map((m) => (m.id === id ? { ...m, read: true } : m)),
        })),

      sendMail: (msg) => {
        const t = Date.now();
        set((s) => ({
          mail: [
            {
              ...msg,
              id: uid("m"),
              folder: "sent",
              at: t,
              read: true,
              from: s.mailbox.address,
            },
            ...s.mail,
          ],
          syncLog: s.mailbox.connected
            ? log(s, "out", `Email sent: ${msg.subject}`)
            : s.syncLog,
        }));
      },

      acknowledgeEvent: (id) =>
        set((s) => ({
          events: s.events.map((e) =>
            e.id === id ? { ...e, acknowledged: true } : e,
          ),
        })),

      injectEvent: (kind) => {
        const t = Date.now();
        const catalog = {
          traffic: {
            id: uid("ev"),
            kind: "traffic" as const,
            severity: "critical" as const,
            title: "I-110 SB stall at 47 interchange",
            detail:
              "Jackknifed chassis blocking the collector. Divert harbor-bound units to Alameda or I-710 SB if 710 has reopened a lane.",
            corridorId: "i110",
          },
          "terminal-line": {
            id: uid("ev"),
            kind: "terminal-line" as const,
            severity: "watch" as const,
            title: "TTI out-gate OCR down",
            detail:
              "Manual processing. Out-gate adding 20 minutes. Hold duals, finish wheeled pickups first.",
            terminalId: "tti",
          },
          weather: {
            id: uid("ev"),
            kind: "weather" as const,
            severity: "watch" as const,
            title: "Dense fog Inner Harbor",
            detail:
              "Visibility under 500 ft on Terminal Island. Speed restricted. Expect gate metering.",
            terminalId: "apm",
          },
          chassis: {
            id: uid("ev"),
            kind: "chassis" as const,
            severity: "critical" as const,
            title: "Pool lockout at YTI",
            detail:
              "No 20' or 40' street-turn wheels. Send only trucks already on chassis.",
            terminalId: "yti",
          },
        }[kind];
        set((s) => {
          let terminals = s.terminals;
          let corridors = s.corridors;
          if (kind === "traffic") {
            corridors = corridors.map((c) =>
              c.id === "i110"
                ? { ...c, congestion: 88, delayMin: 28, status: "slow" as const, note: catalog.detail }
                : c,
            );
          }
          if (kind === "terminal-line") {
            terminals = terminals.map((tm) =>
              tm.id === "tti"
                ? { ...tm, waitMin: tm.waitMin + 22, lineTrucks: tm.lineTrucks + 9, gateStatus: "slow" as const }
                : tm,
            );
          }
          return {
            events: [{ ...catalog, at: t, acknowledged: false }, ...s.events],
            terminals,
            corridors,
            syncLog: s.mc3.connected
              ? log(s, "in", `MC3 exception: ${catalog.title}`)
              : s.syncLog,
          };
        });
      },

      assignDriver: (loadId, driverId) =>
        set((s) => {
          const load = s.loads.find((l) => l.id === loadId);
          const driver = driverById(s.drivers, driverId);
          if (!load || !driver) return s;
          const origin = terminalById(s.terminals, load.originId);
          return {
            loads: s.loads.map((l) =>
              l.id === loadId
                ? {
                    ...l,
                    driverId,
                    status: l.status === "planned" ? "dispatched" : l.status,
                  }
                : l.driverId === driverId
                  ? { ...l, driverId: null }
                  : l,
            ),
            drivers: s.drivers.map((d) => {
              if (d.id === load.driverId && d.id !== driverId) {
                return { ...d, loadId: null, status: "available" as const };
              }
              if (d.id === driverId) {
                return {
                  ...d,
                  loadId,
                  status: "assigned" as const,
                  locationLabel: origin ? `Assigned · ${origin.code}` : "Assigned",
                };
              }
              return d;
            }),
            syncLog:
              s.mc3.connected && s.mc3.autoPush
                ? log(s, "out", `MC3 ${load.mc3MoveId} assigned to truck ${driver.truck}`)
                : s.syncLog,
            mc3:
              s.mc3.connected && s.mc3.autoPush
                ? { ...s.mc3, lastPush: Date.now() }
                : s.mc3,
          };
        }),

      updateLoadRoute: (loadId, route) =>
        set((s) => ({
          loads: s.loads.map((l) => (l.id === loadId ? { ...l, route } : l)),
        })),

      setLoadStatus: (loadId, status) =>
        set((s) => ({
          loads: s.loads.map((l) => (l.id === loadId ? { ...l, status } : l)),
        })),

      applyRecommendation: (planId, recoId) =>
        set((s) => {
          const plan = s.plans.find((p) => p.id === planId);
          const reco = plan?.recommendations.find((r) => r.id === recoId);
          if (!reco || reco.status !== "proposed") return s;
          const applied = applyRecoToState(s, reco);
          return {
            ...applied,
            plans: applied.plans.map((p) =>
              p.id === planId
                ? {
                    ...p,
                    recommendations: p.recommendations.map((r) =>
                      r.id === recoId ? { ...r, status: "applied" } : r,
                    ),
                  }
                : p,
            ),
          };
        }),

      dismissRecommendation: (planId, recoId) =>
        set((s) => ({
          plans: s.plans.map((p) =>
            p.id === planId
              ? {
                  ...p,
                  recommendations: p.recommendations.map((r) =>
                    r.id === recoId && r.status === "proposed"
                      ? { ...r, status: "dismissed" }
                      : r,
                  ),
                }
              : p,
          ),
        })),

      applyAllRecommendations: (planId) =>
        set((s) => {
          const plan = s.plans.find((p) => p.id === planId);
          if (!plan) return {};
          let next: DispatchState = s;
          for (const reco of plan.recommendations) {
            if (reco.status === "proposed") next = applyRecoToState(next, reco);
          }
          return {
            loads: next.loads,
            drivers: next.drivers,
            mail: next.mail,
            mc3: next.mc3,
            syncLog: next.syncLog,
            plans: next.plans.map((p) =>
              p.id === planId
                ? {
                    ...p,
                    recommendations: p.recommendations.map((r) =>
                      r.status === "proposed" ? { ...r, status: "applied" as const } : r,
                    ),
                  }
                : p,
            ),
          };
        }),

      addPlan: (plan) =>
        set((s) => ({
          plans: [plan, ...s.plans].slice(0, 8),
          view: "planner",
        })),

      tickSim: () =>
        set((s) => {
          const t = Date.now();
          const drivers = s.drivers.map((d) => {
            if (d.status === "offline") return d;
            const drift = (n: number) =>
              Math.max(8, Math.min(92, n + (Math.random() - 0.45) * 1.4));
            const moving = d.status === "driving";
            return {
              ...d,
              x: moving ? drift(d.x) : d.x,
              y: moving ? drift(d.y - 0.15) : d.y,
              lastPing: s.mc3.connected ? t - Math.random() * 8000 : d.lastPing,
              hosRemainMin: Math.max(0, d.hosRemainMin - 0.2),
            };
          });
          const terminals = s.terminals.map((tm) => {
            const delta = (Math.random() - 0.48) * 4;
            const waitMin = Math.max(5, Math.round(tm.waitMin + delta));
            const lineTrucks = Math.max(1, Math.round(tm.lineTrucks + (Math.random() - 0.5) * 2));
            let gateStatus: Terminal["gateStatus"] = tm.gateStatus;
            if (waitMin > 180) gateStatus = "hold";
            else if (waitMin > 100) gateStatus = "slow";
            return { ...tm, waitMin, lineTrucks, gateStatus };
          });
          const corridors = s.corridors.map((c) => {
            if (c.id === "i710" && c.congestion > 40) {
              const congestion = Math.max(20, c.congestion + (Math.random() - 0.55) * 3);
              const status: Corridor["status"] =
                congestion > 90 ? "closed" : congestion > 75 ? "slow" : congestion > 35 ? "slow" : "clear";
              return {
                ...c,
                congestion: Math.round(congestion),
                delayMin: Math.max(0, Math.round(congestion * 0.4 - 4)),
                status,
              };
            }
            const congestion = Math.max(8, Math.min(92, c.congestion + (Math.random() - 0.5) * 2));
            return {
              ...c,
              congestion: Math.round(congestion),
              delayMin: Math.max(0, Math.round(congestion * 0.28 - 4)),
            };
          });
          const loads = s.loads.map((l) => {
            if (l.status === "waiting" || l.status === "at-terminal") {
              const origin = terminals.find((tm) => tm.id === l.originId);
              return {
                ...l,
                waitMin: origin?.waitMin ?? l.waitMin,
                eta: l.eta + (origin && origin.waitMin > l.waitMin ? 60_000 : 0),
              };
            }
            return l;
          });
          return {
            drivers,
            terminals,
            corridors,
            loads,
            tick: s.tick + 1,
          };
        }),

      resetDemo: () => {
        const fresh = createInitialState();
        set({ ...fresh });
      },
    }),
    {
      name: "pierline-dispatch-v1",
      partialize: (s) => ({
        company: s.company,
        shiftStart: s.shiftStart,
        view: s.view,
        selectedLoadId: s.selectedLoadId,
        selectedMailId: s.selectedMailId,
        terminals: s.terminals,
        corridors: s.corridors,
        drivers: s.drivers,
        loads: s.loads,
        events: s.events,
        mail: s.mail,
        plans: s.plans,
        mc3: s.mc3,
        mailbox: s.mailbox,
        syncLog: s.syncLog,
        tick: s.tick,
      }),
    },
  ),
);

export function buildPlannerSnapshot(state: DispatchState) {
  const term = (id: string) => terminalById(state.terminals, id);
  const compactLoads = state.loads
    .filter((l) => l.status !== "complete")
    .map((l) => {
      const d = driverById(state.drivers, l.driverId);
      const o = term(l.originId);
      const dest = term(l.destId);
      return {
        id: l.id,
        mc3: l.mc3MoveId,
        container: l.container,
        status: l.status,
        customer: l.customer,
        origin: o?.code,
        dest: dest?.code,
        originWaitMin: o?.waitMin,
        driver: d ? `${d.name} truck ${d.truck}` : "unassigned",
        hosRemainMin: d?.hosRemainMin,
        route: l.route,
        altRoute: l.altRoute,
        risk: l.risk,
        notes: l.notes,
        driverEmail: d?.email,
      };
    });
  return {
    company: state.company,
    region: "San Pedro Bay / LA-Long Beach drayage",
    mc3Connected: state.mc3.connected,
    terminals: state.terminals.map((t) => ({
      code: t.code,
      waitMin: t.waitMin,
      lineTrucks: t.lineTrucks,
      gate: t.gateStatus,
      notes: t.notes,
    })),
    corridors: state.corridors.map((c) => ({
      name: c.name,
      delayMin: c.delayMin,
      congestion: c.congestion,
      status: c.status,
      note: c.note,
    })),
    openEvents: state.events
      .filter((e) => !e.acknowledged)
      .map((e) => ({ title: e.title, detail: e.detail, severity: e.severity, kind: e.kind })),
    availableDrivers: state.drivers
      .filter((d) => d.status === "available")
      .map((d) => ({
        id: d.id,
        name: d.name,
        truck: d.truck,
        hosRemainMin: d.hosRemainMin,
        chassis: d.chassis,
        email: d.email,
      })),
    loads: compactLoads,
  };
}

export function snapshotLoad(load: Load, state: DispatchState) {
  return {
    load,
    driver: driverById(state.drivers, load.driverId),
    origin: terminalById(state.terminals, load.originId),
    dest: terminalById(state.terminals, load.destId),
  };
}
