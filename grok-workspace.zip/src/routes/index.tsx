import { createFileRoute } from "@tanstack/react-router";
import { DispatchShell } from "@/components/app/shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <DispatchShell />;
}
