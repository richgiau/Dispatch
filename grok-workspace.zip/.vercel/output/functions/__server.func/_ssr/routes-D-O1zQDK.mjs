import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as Map, c as ArrowRight, i as Radio, l as Activity, n as TriangleAlert, o as Mail, r as Settings, s as Container, t as Truck } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D-O1zQDK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var now = () => Date.now();
var mins = (m) => now() + m * 6e4;
var TERMINALS = [
	{
		id: "apm",
		name: "APM Terminals",
		code: "APM",
		kind: "marine",
		x: 62,
		y: 72,
		waitMin: 148,
		lineTrucks: 42,
		gateStatus: "slow",
		notes: "Pier 400 dual transactions backed up. Import duals delayed."
	},
	{
		id: "tti",
		name: "Total Terminals",
		code: "TTI",
		kind: "marine",
		x: 48,
		y: 78,
		waitMin: 54,
		lineTrucks: 18,
		gateStatus: "open",
		notes: "Steady flow. Reefers on appointment only."
	},
	{
		id: "lbct",
		name: "Long Beach Container",
		code: "LBCT",
		kind: "marine",
		x: 38,
		y: 74,
		waitMin: 36,
		lineTrucks: 11,
		gateStatus: "open",
		notes: "Night gates running. Chassis OK."
	},
	{
		id: "pct",
		name: "Pacific Container",
		code: "PCT",
		kind: "marine",
		x: 72,
		y: 64,
		waitMin: 92,
		lineTrucks: 27,
		gateStatus: "slow",
		notes: "Bare chassis pool short 40' tri-axle."
	},
	{
		id: "yti",
		name: "Yusen Terminal",
		code: "YTI",
		kind: "marine",
		x: 56,
		y: 68,
		waitMin: 41,
		lineTrucks: 14,
		gateStatus: "open",
		notes: "Clear. Vessel NYK Oceanus alongside."
	},
	{
		id: "wbct",
		name: "West Basin",
		code: "WBCT",
		kind: "marine",
		x: 78,
		y: 58,
		waitMin: 67,
		lineTrucks: 21,
		gateStatus: "open",
		notes: "Wind advisory on cranes after 20:00."
	},
	{
		id: "ictf",
		name: "ICTF Rail Ramp",
		code: "ICTF",
		kind: "rail",
		x: 44,
		y: 38,
		waitMin: 28,
		lineTrucks: 8,
		gateStatus: "open",
		notes: "UP stack train 90 minutes late inbound."
	},
	{
		id: "sctf",
		name: "BNSF SCTF",
		code: "SCTF",
		kind: "rail",
		x: 28,
		y: 32,
		waitMin: 22,
		lineTrucks: 6,
		gateStatus: "open",
		notes: "Normal. Night lift available."
	},
	{
		id: "yard",
		name: "Pacific Gate Yard",
		code: "PGY",
		kind: "yard",
		x: 34,
		y: 52,
		waitMin: 8,
		lineTrucks: 2,
		gateStatus: "open",
		notes: "12 street-turn boxes staged. 7 bare 40' chassis."
	},
	{
		id: "vernon",
		name: "Vernon DC",
		code: "VRN",
		kind: "customer",
		x: 40,
		y: 22,
		waitMin: 18,
		lineTrucks: 4,
		gateStatus: "open",
		notes: "Receiving until 22:00. Live unload 45 min."
	},
	{
		id: "carson",
		name: "Carson Crossdock",
		code: "CRN",
		kind: "customer",
		x: 22,
		y: 48,
		waitMin: 12,
		lineTrucks: 3,
		gateStatus: "open",
		notes: "Drop lot open. Night guard on duty."
	},
	{
		id: "ontario",
		name: "Ontario Inland",
		code: "ONT",
		kind: "customer",
		x: 86,
		y: 18,
		waitMin: 25,
		lineTrucks: 5,
		gateStatus: "open",
		notes: "Appointment 19:30–21:00. Tight yard."
	}
];
var CORRIDORS = [
	{
		id: "i710",
		name: "I-710 Long Beach Fwy",
		congestion: 86,
		delayMin: 34,
		status: "slow",
		note: "Injury collision NB at I-405. Two lanes blocked."
	},
	{
		id: "i110",
		name: "I-110 Harbor Fwy",
		congestion: 41,
		delayMin: 9,
		status: "slow",
		note: "Typical evening volume. Better than 710."
	},
	{
		id: "i405",
		name: "I-405 San Diego Fwy",
		congestion: 62,
		delayMin: 16,
		status: "slow",
		note: "WB slow Seal Beach to 710 interchange."
	},
	{
		id: "i605",
		name: "I-605 San Gabriel",
		congestion: 28,
		delayMin: 4,
		status: "clear",
		note: "Moving. Preferred inland if 710 stays closed."
	},
	{
		id: "sr91",
		name: "SR-91 Artesia",
		congestion: 55,
		delayMin: 12,
		status: "slow",
		note: "EB backup approaching 710."
	},
	{
		id: "alameda",
		name: "Alameda Corridor",
		congestion: 18,
		delayMin: 2,
		status: "clear",
		note: "Rail corridor clear. Truck bypass open."
	}
];
var DRIVERS = [
	{
		id: "d-vasquez",
		name: "Rafael Vasquez",
		truck: "4412",
		phone: "562-555-0144",
		email: "rvasquez@pgdray.ops",
		status: "waiting",
		hosRemainMin: 312,
		chassis: "TRIN-88312",
		locationLabel: "APM in-gate line",
		x: 60,
		y: 70,
		heading: 18,
		loadId: "mv-1044",
		mc3Online: true,
		lastPing: now() - 22e3
	},
	{
		id: "d-chen",
		name: "Mei Chen",
		truck: "2281",
		phone: "310-555-0192",
		email: "mchen@pgdray.ops",
		status: "driving",
		hosRemainMin: 268,
		chassis: "TRIN-44190",
		locationLabel: "NB 710 at Willow",
		x: 46,
		y: 58,
		heading: 8,
		loadId: "mv-1051",
		mc3Online: true,
		lastPing: now() - 8e3
	},
	{
		id: "d-okonkwo",
		name: "James Okonkwo",
		truck: "5510",
		phone: "213-555-0177",
		email: "jokonkwo@pgdray.ops",
		status: "assigned",
		hosRemainMin: 188,
		chassis: "TRIN-22011",
		locationLabel: "Vernon DC dock 6",
		x: 41,
		y: 24,
		heading: 270,
		loadId: "mv-1038",
		mc3Online: true,
		lastPing: now() - 14e3
	},
	{
		id: "d-reyes",
		name: "Ana Reyes",
		truck: "3304",
		phone: "714-555-0118",
		email: "areyes@pgdray.ops",
		status: "available",
		hosRemainMin: 540,
		chassis: "TRIN-10944",
		locationLabel: "Pacific Gate Yard",
		x: 34,
		y: 50,
		heading: 90,
		loadId: null,
		mc3Online: true,
		lastPing: now() - 5e3
	},
	{
		id: "d-nguyen",
		name: "Tuan Nguyen",
		truck: "1188",
		phone: "562-555-0160",
		email: "tnguyen@pgdray.ops",
		status: "waiting",
		hosRemainMin: 401,
		chassis: "TRIN-77230",
		locationLabel: "LBCT wheeled row C",
		x: 39,
		y: 73,
		heading: 350,
		loadId: "mv-1058",
		mc3Online: true,
		lastPing: now() - 11e3
	},
	{
		id: "d-patel",
		name: "Sanjay Patel",
		truck: "7721",
		phone: "909-555-0133",
		email: "spatel@pgdray.ops",
		status: "driving",
		hosRemainMin: 220,
		chassis: "TRIN-55102",
		locationLabel: "Alameda Corridor NB",
		x: 42,
		y: 44,
		heading: 12,
		loadId: "mv-1062",
		mc3Online: true,
		lastPing: now() - 6e3
	},
	{
		id: "d-brooks",
		name: "Lena Brooks",
		truck: "9902",
		phone: "323-555-0184",
		email: "lbrooks@pgdray.ops",
		status: "assigned",
		hosRemainMin: 48,
		chassis: "TRIN-33018",
		locationLabel: "WBCT out-gate",
		x: 76,
		y: 56,
		heading: 300,
		loadId: "mv-1049",
		mc3Online: true,
		lastPing: now() - 17e3
	},
	{
		id: "d-morales",
		name: "Diego Morales",
		truck: "1044",
		phone: "562-555-0121",
		email: "dmorales@pgdray.ops",
		status: "available",
		hosRemainMin: 490,
		chassis: null,
		locationLabel: "Pacific Gate Yard",
		x: 33,
		y: 54,
		heading: 80,
		loadId: null,
		mc3Online: true,
		lastPing: now() - 4e3
	},
	{
		id: "d-singh",
		name: "Kiran Singh",
		truck: "6615",
		phone: "626-555-0155",
		email: "ksingh@pgdray.ops",
		status: "driving",
		hosRemainMin: 305,
		chassis: "TRIN-88401",
		locationLabel: "SR-91 EB toward 605",
		x: 58,
		y: 36,
		heading: 55,
		loadId: "mv-1070",
		mc3Online: true,
		lastPing: now() - 9e3
	},
	{
		id: "d-walsh",
		name: "Evan Walsh",
		truck: "2180",
		phone: "310-555-0107",
		email: "ewalsh@pgdray.ops",
		status: "offline",
		hosRemainMin: 360,
		chassis: "TRIN-21990",
		locationLabel: "Shoulder I-405 NB",
		x: 52,
		y: 48,
		heading: 0,
		loadId: "mv-1041",
		mc3Online: false,
		lastPing: now() - 114e4
	},
	{
		id: "d-alvarez",
		name: "Priya Alvarez",
		truck: "3847",
		phone: "213-555-0199",
		email: "palvarez@pgdray.ops",
		status: "waiting",
		hosRemainMin: 410,
		chassis: "TRIN-66218",
		locationLabel: "ICTF in-gate",
		x: 44,
		y: 40,
		heading: 20,
		loadId: "mv-1066",
		mc3Online: true,
		lastPing: now() - 13e3
	},
	{
		id: "d-kim",
		name: "Noah Kim",
		truck: "4501",
		phone: "714-555-0142",
		email: "nkim@pgdray.ops",
		status: "available",
		hosRemainMin: 520,
		chassis: "TRIN-44101",
		locationLabel: "Pacific Gate Yard",
		x: 36,
		y: 51,
		heading: 100,
		loadId: null,
		mc3Online: true,
		lastPing: now() - 3e3
	}
];
var LOADS = [
	{
		id: "mv-1044",
		container: "TCLU 4482913",
		size: "40HC",
		type: "import",
		customer: "Harbor Foods",
		ssl: "Maersk",
		booking: "MAEU 882910",
		status: "waiting",
		driverId: "d-vasquez",
		originId: "apm",
		destId: "vernon",
		route: "APM → I-710 NB → Vernon DC",
		altRoute: "APM → Alameda St → I-110 NB → Vernon",
		eta: mins(95),
		risk: "high",
		waitMin: 148,
		notes: "Dual transaction. Customer cutoff 21:00.",
		mc3MoveId: "MC3-88421",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "apm",
			appointment: "18:00–19:00",
			status: "active"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "vernon",
			appointment: "20:00–21:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1051",
		container: "FSCU 1192044",
		size: "40",
		type: "import",
		customer: "Westline Retail",
		ssl: "MSC",
		booking: "MSCU 441882",
		status: "en-route",
		driverId: "d-chen",
		originId: "tti",
		destId: "carson",
		route: "TTI → I-710 NB → Carson",
		altRoute: "TTI → I-110 via 47 → Carson",
		eta: mins(38),
		risk: "high",
		waitMin: 0,
		notes: "On 710 heading into the collision zone.",
		mc3MoveId: "MC3-88430",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "tti",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "carson",
			appointment: "19:30 drop",
			status: "active"
		}]
	},
	{
		id: "mv-1038",
		container: "TEMU 7721908",
		size: "40HC",
		type: "export",
		customer: "Pacific Grain",
		ssl: "CMA CGM",
		booking: "CMDU 990211",
		status: "at-customer",
		driverId: "d-okonkwo",
		originId: "vernon",
		destId: "yti",
		route: "Vernon → I-110 SB → YTI",
		altRoute: "Vernon → Alameda SB → YTI",
		eta: mins(110),
		risk: "medium",
		waitMin: 18,
		notes: "Live load in progress. Cutoff 22:00 YTI.",
		mc3MoveId: "MC3-88390",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "live-load",
			locationId: "vernon",
			status: "active"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "yti",
			appointment: "21:00–22:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1058",
		container: "MSCU 3301982",
		size: "40HC",
		type: "import",
		customer: "Nexus Apparel",
		ssl: "MSC",
		booking: "MSCU 552019",
		status: "at-terminal",
		driverId: "d-nguyen",
		originId: "lbct",
		destId: "ontario",
		route: "LBCT → I-710 → SR-91 → I-15 → Ontario",
		altRoute: "LBCT → I-605 → SR-60 → Ontario",
		eta: mins(155),
		risk: "medium",
		waitMin: 36,
		notes: "Inland run. Avoid 710 if still blocked.",
		mc3MoveId: "MC3-88444",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "lbct",
			appointment: "18:30–19:30",
			status: "active"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "ontario",
			appointment: "21:00–22:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1062",
		container: "CMAU 8812933",
		size: "40",
		type: "import",
		customer: "Rail Bridge Co.",
		ssl: "CMA CGM",
		booking: "CMDU 110294",
		status: "en-route",
		driverId: "d-patel",
		originId: "yard",
		destId: "ictf",
		route: "Yard → Alameda Corridor → ICTF",
		altRoute: "Yard → I-710 → ICTF",
		eta: mins(22),
		risk: "low",
		waitMin: 0,
		notes: "Street turn to rail. On preferred corridor.",
		mc3MoveId: "MC3-88451",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "yard",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "ictf",
			appointment: "19:00 lift",
			status: "active"
		}]
	},
	{
		id: "mv-1049",
		container: "ONEU 2291045",
		size: "45",
		type: "import",
		customer: "Inland Paper",
		ssl: "ONE",
		booking: "ONEY 772841",
		status: "dispatched",
		driverId: "d-brooks",
		originId: "wbct",
		destId: "ontario",
		route: "WBCT → I-110 → I-105 → I-605 → Ontario",
		altRoute: "Hold at yard, flip to night driver",
		eta: mins(170),
		risk: "high",
		waitMin: 12,
		notes: "Driver HOS 48 min remaining. Inland run is 90+ min.",
		mc3MoveId: "MC3-88418",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "wbct",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "ontario",
			appointment: "21:30–22:30",
			status: "pending"
		}]
	},
	{
		id: "mv-1070",
		container: "HLXU 5510288",
		size: "40HC",
		type: "export",
		customer: "AeroParts LA",
		ssl: "Hapag",
		booking: "HLCU 339201",
		status: "en-route",
		driverId: "d-singh",
		originId: "ontario",
		destId: "pct",
		route: "Ontario → SR-60 → I-605 SB → PCT",
		altRoute: "Ontario → I-15 SB → SR-91 → I-710 → PCT",
		eta: mins(80),
		risk: "medium",
		waitMin: 0,
		notes: "Export cutoff 21:30. Chassis pool tight at PCT.",
		mc3MoveId: "MC3-88460",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "ontario",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "pct",
			appointment: "20:30–21:30",
			status: "active"
		}]
	},
	{
		id: "mv-1041",
		container: "TCLU 9912041",
		size: "20",
		type: "import",
		customer: "Metro Chem",
		ssl: "Maersk",
		booking: "MAEU 119304",
		status: "hold",
		driverId: "d-walsh",
		originId: "yti",
		destId: "carson",
		route: "YTI → I-405 NB → Carson",
		altRoute: "Rescue with yard truck via I-110",
		eta: mins(70),
		risk: "high",
		waitMin: 0,
		notes: "Tractor air leak. MC3 geofence stale 19 min.",
		mc3MoveId: "MC3-88405",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "yti",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "carson",
			appointment: "19:00–20:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1066",
		container: "EMCU 4401987",
		size: "40HC",
		type: "import",
		customer: "Rail Bridge Co.",
		ssl: "Evergreen",
		booking: "EGLV 228193",
		status: "waiting",
		driverId: "d-alvarez",
		originId: "ictf",
		destId: "yard",
		route: "ICTF → Alameda SB → Yard",
		altRoute: "ICTF → I-710 SB → Yard",
		eta: mins(45),
		risk: "low",
		waitMin: 28,
		notes: "Ramp lift delayed with late stack train.",
		mc3MoveId: "MC3-88455",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "ictf",
			appointment: "18:45",
			status: "active"
		}, {
			id: "l2",
			sequence: 2,
			action: "drop",
			locationId: "yard",
			status: "pending"
		}]
	},
	{
		id: "mv-1077",
		container: "FSCU 2288110",
		size: "40HC",
		type: "import",
		customer: "Harbor Foods",
		ssl: "Maersk",
		booking: "MAEU 883044",
		status: "planned",
		driverId: null,
		originId: "apm",
		destId: "vernon",
		route: "APM → I-710 → Vernon",
		altRoute: "Hold until APM duals clear, then Alameda",
		eta: mins(210),
		risk: "high",
		waitMin: 0,
		notes: "Second box same customer. Do not send into APM pile-up.",
		mc3MoveId: "MC3-88471",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "apm",
			appointment: "20:00–21:00",
			status: "pending"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "vernon",
			appointment: "22:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1080",
		container: "TCLU 1102948",
		size: "40",
		type: "street-turn",
		customer: "Westline Retail",
		ssl: "MSC",
		booking: "MSCU 441900",
		status: "planned",
		driverId: null,
		originId: "carson",
		destId: "tti",
		route: "Carson empty → TTI export load",
		altRoute: "Carson → Yard stage if TTI appointment slips",
		eta: mins(240),
		risk: "low",
		waitMin: 0,
		notes: "Street-turn candidate. Saves a deadhead to the port.",
		mc3MoveId: "MC3-88480",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "carson",
			status: "pending"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "tti",
			appointment: "21:00–22:00",
			status: "pending"
		}]
	},
	{
		id: "mv-1022",
		container: "CMAU 2291884",
		size: "40HC",
		type: "import",
		customer: "Nexus Apparel",
		ssl: "CMA CGM",
		booking: "CMDU 881045",
		status: "complete",
		driverId: "d-reyes",
		originId: "lbct",
		destId: "carson",
		route: "LBCT → I-110 → Carson",
		altRoute: "",
		eta: mins(-40),
		risk: "low",
		waitMin: 0,
		notes: "POD captured in MC3. Empty still at Carson.",
		mc3MoveId: "MC3-88340",
		legs: [{
			id: "l1",
			sequence: 1,
			action: "pickup",
			locationId: "lbct",
			status: "done"
		}, {
			id: "l2",
			sequence: 2,
			action: "deliver",
			locationId: "carson",
			status: "done"
		}]
	}
];
var EVENTS = [
	{
		id: "ev-710",
		kind: "traffic",
		severity: "critical",
		title: "I-710 NB collision at 405",
		detail: "CHP reports two lanes blocked northbound. Expect 30–45 minutes extra through the harbor. Prefer I-110 or Alameda until cleared.",
		at: now() - 108e4,
		corridorId: "i710",
		acknowledged: false
	},
	{
		id: "ev-apm",
		kind: "terminal-line",
		severity: "critical",
		title: "APM duals backed up 2.5 hours",
		detail: "Pier 400 in-gate line 42 trucks. Dual transactions averaging 148 minutes. Night duals after 20:00 may be faster.",
		at: now() - 252e4,
		terminalId: "apm",
		loadId: "mv-1044",
		acknowledged: false
	},
	{
		id: "ev-walsh",
		kind: "breakdown",
		severity: "critical",
		title: "Truck 2180 air leak on I-405",
		detail: "Evan Walsh offline in MC3. Stale GPS 19 minutes. 20' Metro Chem box on chassis. Needs rescue or tow.",
		at: now() - 114e4,
		driverId: "d-walsh",
		loadId: "mv-1041",
		corridorId: "i405",
		acknowledged: false
	},
	{
		id: "ev-hos",
		kind: "hos",
		severity: "watch",
		title: "Brooks HOS 48 minutes remaining",
		detail: "Inland Paper 45' cannot legally finish Ontario tonight. Flip to night driver or drop at yard.",
		at: now() - 48e4,
		driverId: "d-brooks",
		loadId: "mv-1049",
		acknowledged: false
	},
	{
		id: "ev-pct",
		kind: "chassis",
		severity: "watch",
		title: "PCT 40' chassis pool short",
		detail: "Bare tri-axle inventory thin. Exports may wait for wheels. Stage street-turns from Carson if possible.",
		at: now() - 33e5,
		terminalId: "pct",
		acknowledged: false
	},
	{
		id: "ev-up",
		kind: "vessel",
		severity: "watch",
		title: "UP stack train 90 min late into ICTF",
		detail: "Ramp lifts slipping. Alvarez (mv-1066) already in gate. Further ICTF pickups should hold.",
		at: now() - 42e5,
		terminalId: "ictf",
		loadId: "mv-1066",
		acknowledged: false
	},
	{
		id: "ev-wind",
		kind: "weather",
		severity: "info",
		title: "WBCT crane wind after 20:00",
		detail: "Harbor wind building. WBCT may pause ship-to-shore. Grounded boxes still available.",
		at: now() - 15e5,
		terminalId: "wbct",
		acknowledged: true
	}
];
var MAIL = [
	{
		id: "m-1",
		folder: "inbox",
		from: "tenders@maersk.com",
		to: "dispatch@pacificgate.dray",
		subject: "Tender MAEU 883044 — TCLU 110? Harbor Foods second box",
		body: "Please pick up TCLU (40HC) at APM Terminals tonight, appointment 20:00–21:00, deliver Vernon DC same night. Last free day tomorrow 07:00. Confirm driver and ETA.",
		at: now() - 156e4,
		read: false,
		loadId: "mv-1077",
		kind: "tender"
	},
	{
		id: "m-2",
		folder: "inbox",
		from: "ops@portoflosangeles.org",
		to: "dispatch@pacificgate.dray",
		subject: "Advisory: APM Pier 400 dual transaction congestion",
		body: "In-gate wait currently exceeds two hours for duals. Consider single transactions or later appointments. Night gate remains open until 03:00.",
		at: now() - 24e5,
		read: false,
		kind: "advisory",
		loadId: "mv-1044"
	},
	{
		id: "m-3",
		folder: "inbox",
		from: "ewalsh@pgdray.ops",
		to: "dispatch@pacificgate.dray",
		subject: "2180 down — air leak NB 405",
		body: "Pulled onto the shoulder north of Wilmington. Warning lights on. Box is still locked. Need a rescue truck or roadside. Not safe to continue.",
		at: now() - 108e4,
		read: false,
		kind: "driver",
		driverId: "d-walsh",
		loadId: "mv-1041"
	},
	{
		id: "m-4",
		folder: "inbox",
		from: "yard@inlandpaper.com",
		to: "dispatch@pacificgate.dray",
		subject: "Receiving window Ontario — confirm 21:30",
		body: "We can take the 45' until 22:30 tonight. After that the lot closes. Please update ETA if you are flipping drivers.",
		at: now() - 72e4,
		read: true,
		kind: "customer",
		loadId: "mv-1049"
	},
	{
		id: "m-5",
		folder: "sent",
		from: "dispatch@pacificgate.dray",
		to: "tnguyen@pgdray.ops",
		subject: "MC3 dispatch — MSCU 3301982 LBCT to Ontario",
		body: "Tuan, you are assigned MSCU 3301982 at LBCT, appointment 18:30. If 710 is still blocked after out-gate, take 605 to 60. Customer window 21:00–22:00 Ontario Inland.",
		at: now() - 57e5,
		read: true,
		kind: "plan",
		driverId: "d-nguyen",
		loadId: "mv-1058"
	}
];
function createInitialState() {
	const t = now();
	return {
		company: "Pacific Gate Drayage",
		shiftStart: t - 216e5,
		view: "dispatch",
		selectedLoadId: "mv-1044",
		selectedMailId: "m-1",
		terminals: TERMINALS.map((x) => ({ ...x })),
		corridors: CORRIDORS.map((x) => ({ ...x })),
		drivers: DRIVERS.map((d) => ({ ...d })),
		loads: LOADS.map((l) => ({
			...l,
			legs: l.legs.map((leg) => ({ ...leg }))
		})),
		events: EVENTS.map((e) => ({ ...e })),
		mail: MAIL.map((m) => ({ ...m })),
		plans: [],
		mc3: {
			connected: false,
			tenant: "pacificgate.trinium.cloud",
			apiKeySet: false,
			environment: "sandbox",
			lastSync: null,
			lastPush: null,
			lastError: null,
			autoPush: true
		},
		mailbox: {
			connected: false,
			address: "dispatch@pacificgate.dray",
			lastPull: null
		},
		syncLog: [{
			id: "log-0",
			at: t - 12e4,
			direction: "in",
			message: "Idle — connect Trinium MC3 to start GPS and leg heartbeats."
		}],
		tick: 0
	};
}
function terminalById(terminals, id) {
	return terminals.find((t) => t.id === id);
}
function driverById(drivers, id) {
	if (!id) return void 0;
	return drivers.find((d) => d.id === id);
}
var STATUS_LABEL = {
	planned: "Planned",
	dispatched: "Dispatched",
	"at-terminal": "At terminal",
	waiting: "Waiting",
	"en-route": "En route",
	"at-customer": "At customer",
	complete: "Complete",
	hold: "Hold",
	available: "Available",
	assigned: "Assigned",
	driving: "Driving",
	offline: "Offline",
	open: "Open",
	slow: "Slow",
	closed: "Closed",
	clear: "Clear"
};
var KIND_LABEL = {
	traffic: "Traffic",
	"terminal-line": "Terminal line",
	"wait-time": "Wait time",
	breakdown: "Breakdown",
	weather: "Weather",
	vessel: "Vessel / rail",
	chassis: "Chassis",
	hos: "Hours of service",
	appointment: "Appointment",
	other: "Event",
	tender: "Tender",
	advisory: "Advisory",
	driver: "Driver",
	customer: "Customer",
	plan: "Plan change"
};
function uid(prefix) {
	return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}
function log(state, direction, message) {
	return [{
		id: uid("log"),
		at: Date.now(),
		direction,
		message
	}, ...state.syncLog].slice(0, 40);
}
function applyRecoToState(state, reco) {
	let next = { ...state };
	const t = Date.now();
	if (reco.loadId && reco.newRoute) next.loads = next.loads.map((l) => l.id === reco.loadId ? {
		...l,
		route: reco.newRoute,
		risk: "medium"
	} : l);
	if (reco.loadId && reco.newStatus) next.loads = next.loads.map((l) => l.id === reco.loadId ? {
		...l,
		status: reco.newStatus
	} : l);
	if (reco.loadId && reco.newDriverId) {
		const prev = next.loads.find((l) => l.id === reco.loadId);
		next.drivers = next.drivers.map((d) => {
			if (d.id === prev?.driverId) return {
				...d,
				loadId: null,
				status: "available"
			};
			if (d.id === reco.newDriverId) {
				const loc = next.loads.find((l) => l.id === reco.loadId);
				const term = loc ? terminalById(next.terminals, loc.originId) : void 0;
				return {
					...d,
					loadId: reco.loadId,
					status: "assigned",
					locationLabel: term ? `Assigned · ${term.code}` : "Assigned"
				};
			}
			return d;
		});
		next.loads = next.loads.map((l) => l.id === reco.loadId ? {
			...l,
			driverId: reco.newDriverId,
			status: "dispatched"
		} : l);
	}
	if (reco.emailDraft) next.mail = [{
		id: uid("m"),
		folder: "drafts",
		from: next.mailbox.address,
		to: reco.emailDraft.to,
		subject: reco.emailDraft.subject,
		body: reco.emailDraft.body,
		at: t,
		read: true,
		loadId: reco.loadId,
		driverId: reco.driverId,
		kind: "plan"
	}, ...next.mail];
	if (next.mc3.connected && next.mc3.autoPush && reco.loadId) {
		const load = next.loads.find((l) => l.id === reco.loadId);
		next.mc3 = {
			...next.mc3,
			lastPush: t
		};
		next.syncLog = log(next, "out", `MC3 assignment ${load?.mc3MoveId ?? reco.loadId}: ${reco.title}`);
	}
	return next;
}
var useDispatch = create()(persist((set, get) => ({
	...createInitialState(),
	setView: (view) => set({ view }),
	selectLoad: (id) => set({ selectedLoadId: id }),
	selectMail: (id) => set({ selectedMailId: id }),
	setAutoPush: (autoPush) => set((s) => ({ mc3: {
		...s.mc3,
		autoPush
	} })),
	connectMc3: (tenant, apiKey, environment) => {
		if (apiKey.trim().length < 8) {
			set((s) => ({ mc3: {
				...s.mc3,
				lastError: "MC3 key must be at least 8 characters."
			} }));
			return;
		}
		const t = Date.now();
		set((s) => ({
			mc3: {
				connected: true,
				tenant: tenant.trim() || "pacificgate.trinium.cloud",
				apiKeySet: true,
				environment,
				lastSync: t,
				lastPush: null,
				lastError: null,
				autoPush: s.mc3.autoPush
			},
			drivers: s.drivers.map((d) => ({
				...d,
				mc3Online: d.status !== "offline",
				lastPing: d.status === "offline" ? d.lastPing : t
			})),
			syncLog: log(s, "in", `Connected ${environment} tenant ${tenant}. Pulled ${s.drivers.length} units, ${s.loads.length} moves.`)
		}));
	},
	disconnectMc3: () => set((s) => ({
		mc3: {
			...s.mc3,
			connected: false,
			lastError: null
		},
		syncLog: log(s, "out", "MC3 session closed.")
	})),
	syncMc3: () => {
		const s = get();
		if (!s.mc3.connected) return;
		const t = Date.now();
		const online = s.drivers.filter((d) => d.mc3Online).length;
		set({
			mc3: {
				...s.mc3,
				lastSync: t,
				lastError: null
			},
			drivers: s.drivers.map((d) => d.status === "offline" ? d : {
				...d,
				lastPing: t - Math.random() * 12e3
			}),
			syncLog: log(s, "in", `Heartbeat ${online} MC3 units. GPS + geofence legs refreshed.`)
		});
	},
	connectMailbox: (address) => {
		const addr = address.trim();
		if (!addr.includes("@")) return;
		const t = Date.now();
		set((s) => ({
			mailbox: {
				connected: true,
				address: addr,
				lastPull: t
			},
			syncLog: log(s, "in", `Mailbox linked: ${addr}. Pulled ${s.mail.filter((m) => m.folder === "inbox").length} inbound.`)
		}));
	},
	disconnectMailbox: () => set((s) => ({ mailbox: {
		...s.mailbox,
		connected: false
	} })),
	pullMail: () => {
		const s = get();
		if (!s.mailbox.connected) return;
		const t = Date.now();
		const advisory = {
			id: uid("m"),
			folder: "inbox",
			from: "chp-alerts@dot.ca.gov",
			to: s.mailbox.address,
			subject: "Traffic pulse — harbor corridors",
			body: `I-710 delay ${s.corridors.find((c) => c.id === "i710")?.delayMin ?? 0} min. APM wait ${s.terminals.find((t) => t.id === "apm")?.waitMin ?? 0} min. Generated from the latest corridor scan.`,
			at: t,
			read: false,
			kind: "advisory"
		};
		set({
			mailbox: {
				...s.mailbox,
				lastPull: t
			},
			mail: [advisory, ...s.mail]
		});
	},
	markMailRead: (id) => set((s) => ({ mail: s.mail.map((m) => m.id === id ? {
		...m,
		read: true
	} : m) })),
	sendMail: (msg) => {
		const t = Date.now();
		set((s) => ({
			mail: [{
				...msg,
				id: uid("m"),
				folder: "sent",
				at: t,
				read: true,
				from: s.mailbox.address
			}, ...s.mail],
			syncLog: s.mailbox.connected ? log(s, "out", `Email sent: ${msg.subject}`) : s.syncLog
		}));
	},
	acknowledgeEvent: (id) => set((s) => ({ events: s.events.map((e) => e.id === id ? {
		...e,
		acknowledged: true
	} : e) })),
	injectEvent: (kind) => {
		const t = Date.now();
		const catalog = {
			traffic: {
				id: uid("ev"),
				kind: "traffic",
				severity: "critical",
				title: "I-110 SB stall at 47 interchange",
				detail: "Jackknifed chassis blocking the collector. Divert harbor-bound units to Alameda or I-710 SB if 710 has reopened a lane.",
				corridorId: "i110"
			},
			"terminal-line": {
				id: uid("ev"),
				kind: "terminal-line",
				severity: "watch",
				title: "TTI out-gate OCR down",
				detail: "Manual processing. Out-gate adding 20 minutes. Hold duals, finish wheeled pickups first.",
				terminalId: "tti"
			},
			weather: {
				id: uid("ev"),
				kind: "weather",
				severity: "watch",
				title: "Dense fog Inner Harbor",
				detail: "Visibility under 500 ft on Terminal Island. Speed restricted. Expect gate metering.",
				terminalId: "apm"
			},
			chassis: {
				id: uid("ev"),
				kind: "chassis",
				severity: "critical",
				title: "Pool lockout at YTI",
				detail: "No 20' or 40' street-turn wheels. Send only trucks already on chassis.",
				terminalId: "yti"
			}
		}[kind];
		set((s) => {
			let terminals = s.terminals;
			let corridors = s.corridors;
			if (kind === "traffic") corridors = corridors.map((c) => c.id === "i110" ? {
				...c,
				congestion: 88,
				delayMin: 28,
				status: "slow",
				note: catalog.detail
			} : c);
			if (kind === "terminal-line") terminals = terminals.map((tm) => tm.id === "tti" ? {
				...tm,
				waitMin: tm.waitMin + 22,
				lineTrucks: tm.lineTrucks + 9,
				gateStatus: "slow"
			} : tm);
			return {
				events: [{
					...catalog,
					at: t,
					acknowledged: false
				}, ...s.events],
				terminals,
				corridors,
				syncLog: s.mc3.connected ? log(s, "in", `MC3 exception: ${catalog.title}`) : s.syncLog
			};
		});
	},
	assignDriver: (loadId, driverId) => set((s) => {
		const load = s.loads.find((l) => l.id === loadId);
		const driver = driverById(s.drivers, driverId);
		if (!load || !driver) return s;
		const origin = terminalById(s.terminals, load.originId);
		return {
			loads: s.loads.map((l) => l.id === loadId ? {
				...l,
				driverId,
				status: l.status === "planned" ? "dispatched" : l.status
			} : l.driverId === driverId ? {
				...l,
				driverId: null
			} : l),
			drivers: s.drivers.map((d) => {
				if (d.id === load.driverId && d.id !== driverId) return {
					...d,
					loadId: null,
					status: "available"
				};
				if (d.id === driverId) return {
					...d,
					loadId,
					status: "assigned",
					locationLabel: origin ? `Assigned · ${origin.code}` : "Assigned"
				};
				return d;
			}),
			syncLog: s.mc3.connected && s.mc3.autoPush ? log(s, "out", `MC3 ${load.mc3MoveId} assigned to truck ${driver.truck}`) : s.syncLog,
			mc3: s.mc3.connected && s.mc3.autoPush ? {
				...s.mc3,
				lastPush: Date.now()
			} : s.mc3
		};
	}),
	updateLoadRoute: (loadId, route) => set((s) => ({ loads: s.loads.map((l) => l.id === loadId ? {
		...l,
		route
	} : l) })),
	setLoadStatus: (loadId, status) => set((s) => ({ loads: s.loads.map((l) => l.id === loadId ? {
		...l,
		status
	} : l) })),
	applyRecommendation: (planId, recoId) => set((s) => {
		const reco = s.plans.find((p) => p.id === planId)?.recommendations.find((r) => r.id === recoId);
		if (!reco || reco.status !== "proposed") return s;
		const applied = applyRecoToState(s, reco);
		return {
			...applied,
			plans: applied.plans.map((p) => p.id === planId ? {
				...p,
				recommendations: p.recommendations.map((r) => r.id === recoId ? {
					...r,
					status: "applied"
				} : r)
			} : p)
		};
	}),
	dismissRecommendation: (planId, recoId) => set((s) => ({ plans: s.plans.map((p) => p.id === planId ? {
		...p,
		recommendations: p.recommendations.map((r) => r.id === recoId && r.status === "proposed" ? {
			...r,
			status: "dismissed"
		} : r)
	} : p) })),
	applyAllRecommendations: (planId) => set((s) => {
		const plan = s.plans.find((p) => p.id === planId);
		if (!plan) return {};
		let next = s;
		for (const reco of plan.recommendations) if (reco.status === "proposed") next = applyRecoToState(next, reco);
		return {
			loads: next.loads,
			drivers: next.drivers,
			mail: next.mail,
			mc3: next.mc3,
			syncLog: next.syncLog,
			plans: next.plans.map((p) => p.id === planId ? {
				...p,
				recommendations: p.recommendations.map((r) => r.status === "proposed" ? {
					...r,
					status: "applied"
				} : r)
			} : p)
		};
	}),
	addPlan: (plan) => set((s) => ({
		plans: [plan, ...s.plans].slice(0, 8),
		view: "planner"
	})),
	tickSim: () => set((s) => {
		const t = Date.now();
		const drivers = s.drivers.map((d) => {
			if (d.status === "offline") return d;
			const drift = (n) => Math.max(8, Math.min(92, n + (Math.random() - .45) * 1.4));
			const moving = d.status === "driving";
			return {
				...d,
				x: moving ? drift(d.x) : d.x,
				y: moving ? drift(d.y - .15) : d.y,
				lastPing: s.mc3.connected ? t - Math.random() * 8e3 : d.lastPing,
				hosRemainMin: Math.max(0, d.hosRemainMin - .2)
			};
		});
		const terminals = s.terminals.map((tm) => {
			const delta = (Math.random() - .48) * 4;
			const waitMin = Math.max(5, Math.round(tm.waitMin + delta));
			const lineTrucks = Math.max(1, Math.round(tm.lineTrucks + (Math.random() - .5) * 2));
			let gateStatus = tm.gateStatus;
			if (waitMin > 180) gateStatus = "hold";
			else if (waitMin > 100) gateStatus = "slow";
			return {
				...tm,
				waitMin,
				lineTrucks,
				gateStatus
			};
		});
		return {
			drivers,
			terminals,
			corridors: s.corridors.map((c) => {
				if (c.id === "i710" && c.congestion > 40) {
					const congestion = Math.max(20, c.congestion + (Math.random() - .55) * 3);
					const status = congestion > 90 ? "closed" : congestion > 75 ? "slow" : congestion > 35 ? "slow" : "clear";
					return {
						...c,
						congestion: Math.round(congestion),
						delayMin: Math.max(0, Math.round(congestion * .4 - 4)),
						status
					};
				}
				const congestion = Math.max(8, Math.min(92, c.congestion + (Math.random() - .5) * 2));
				return {
					...c,
					congestion: Math.round(congestion),
					delayMin: Math.max(0, Math.round(congestion * .28 - 4))
				};
			}),
			loads: s.loads.map((l) => {
				if (l.status === "waiting" || l.status === "at-terminal") {
					const origin = terminals.find((tm) => tm.id === l.originId);
					return {
						...l,
						waitMin: origin?.waitMin ?? l.waitMin,
						eta: l.eta + (origin && origin.waitMin > l.waitMin ? 6e4 : 0)
					};
				}
				return l;
			}),
			tick: s.tick + 1
		};
	}),
	resetDemo: () => {
		set({ ...createInitialState() });
	}
}), {
	name: "pierline-dispatch-v1",
	partialize: (s) => ({
		company: s.company,
		shiftStart: s.shiftStart,
		view: s.view,
		selectedLoadId: s.selectedLoadId,
		selectedMailId: s.selectedMailId,
		terminals: s.terminals,
		corridors: s.corridors,
		drivers: s.drivers,
		loads: s.loads,
		events: s.events,
		mail: s.mail,
		plans: s.plans,
		mc3: s.mc3,
		mailbox: s.mailbox,
		syncLog: s.syncLog,
		tick: s.tick
	})
}));
function buildPlannerSnapshot(state) {
	const term = (id) => terminalById(state.terminals, id);
	const compactLoads = state.loads.filter((l) => l.status !== "complete").map((l) => {
		const d = driverById(state.drivers, l.driverId);
		const o = term(l.originId);
		const dest = term(l.destId);
		return {
			id: l.id,
			mc3: l.mc3MoveId,
			container: l.container,
			status: l.status,
			customer: l.customer,
			origin: o?.code,
			dest: dest?.code,
			originWaitMin: o?.waitMin,
			driver: d ? `${d.name} truck ${d.truck}` : "unassigned",
			hosRemainMin: d?.hosRemainMin,
			route: l.route,
			altRoute: l.altRoute,
			risk: l.risk,
			notes: l.notes,
			driverEmail: d?.email
		};
	});
	return {
		company: state.company,
		region: "San Pedro Bay / LA-Long Beach drayage",
		mc3Connected: state.mc3.connected,
		terminals: state.terminals.map((t) => ({
			code: t.code,
			waitMin: t.waitMin,
			lineTrucks: t.lineTrucks,
			gate: t.gateStatus,
			notes: t.notes
		})),
		corridors: state.corridors.map((c) => ({
			name: c.name,
			delayMin: c.delayMin,
			congestion: c.congestion,
			status: c.status,
			note: c.note
		})),
		openEvents: state.events.filter((e) => !e.acknowledged).map((e) => ({
			title: e.title,
			detail: e.detail,
			severity: e.severity,
			kind: e.kind
		})),
		availableDrivers: state.drivers.filter((d) => d.status === "available").map((d) => ({
			id: d.id,
			name: d.name,
			truck: d.truck,
			hosRemainMin: d.hosRemainMin,
			chassis: d.chassis,
			email: d.email
		})),
		loads: compactLoads
	};
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatClock(ts) {
	return new Date(ts).toLocaleTimeString("en-US", {
		hour: "numeric",
		minute: "2-digit"
	});
}
function formatMinutes(mins) {
	if (mins < 60) return `${Math.round(mins)}m`;
	const h = Math.floor(mins / 60);
	const m = Math.round(mins % 60);
	return m ? `${h}h ${m}m` : `${h}h`;
}
function etaLabel(ts, now = Date.now()) {
	const diff = Math.round((ts - now) / 6e4);
	if (diff < -5) return `${formatMinutes(-diff)} late`;
	if (diff < 0) return "due now";
	return formatMinutes(diff);
}
function waitFill(wait) {
	if (wait > 100) return "var(--color-danger)";
	if (wait > 50) return "var(--color-warn)";
	return "var(--color-ok)";
}
function congStroke(c) {
	if (c > 75) return "var(--color-danger)";
	if (c > 40) return "var(--color-warn)";
	return "var(--color-ok)";
}
function HarborMap() {
	const terminals = useDispatch((s) => s.terminals);
	const corridors = useDispatch((s) => s.corridors);
	const drivers = useDispatch((s) => s.drivers);
	const loads = useDispatch((s) => s.loads);
	const selectedLoadId = useDispatch((s) => s.selectedLoadId);
	const selectLoad = useDispatch((s) => s.selectLoad);
	const selectedDriver = driverById(drivers, loads.find((l) => l.id === selectedLoadId)?.driverId ?? null);
	const i710 = corridors.find((c) => c.id === "i710");
	const i110 = corridors.find((c) => c.id === "i110");
	const i405 = corridors.find((c) => c.id === "i405");
	const alameda = corridors.find((c) => c.id === "alameda");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-lg bg-inset shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 100 100",
				className: "block h-auto w-full",
				role: "img",
				"aria-label": "San Pedro Bay operations map",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "100",
						height: "100",
						fill: "var(--color-inset)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 58 C 18 62, 28 70, 40 78 C 52 88, 70 92, 100 86 L 100 100 L 0 100 Z",
						fill: "color-mix(in oklab, var(--color-info) 16%, var(--color-inset))"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M58 78 C 64 74, 78 70, 92 62 L 100 64 L 100 88 C 80 92, 62 88, 52 82 Z",
						fill: "color-mix(in oklab, var(--color-info) 22%, var(--color-inset))"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M46 100 L 44 70 L 42 48 L 40 22 L 38 0",
						fill: "none",
						stroke: congStroke(i710?.congestion ?? 50),
						strokeWidth: "1.6",
						opacity: "0.85"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M62 100 L 58 62 L 50 28 L 48 0",
						fill: "none",
						stroke: congStroke(i110?.congestion ?? 40),
						strokeWidth: "1.3",
						opacity: "0.8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 52 L 30 50 L 58 48 L 100 46",
						fill: "none",
						stroke: congStroke(i405?.congestion ?? 50),
						strokeWidth: "1.2",
						opacity: "0.75"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M40 86 L 42 60 L 44 38 L 46 10",
						fill: "none",
						stroke: congStroke(alameda?.congestion ?? 20),
						strokeWidth: "0.9",
						strokeDasharray: "1.6 1.1",
						opacity: "0.9"
					}),
					terminals.map((tm) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: tm.x,
						cy: tm.y,
						r: tm.kind === "marine" ? 2.4 : 1.8,
						fill: waitFill(tm.waitMin),
						opacity: "0.95"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: tm.x + 3.1,
						y: tm.y + 1,
						fill: "var(--color-fg)",
						fontSize: "2.6",
						fontFamily: "var(--font-mono)",
						children: tm.code
					})] }, tm.id)),
					drivers.filter((d) => d.status !== "available").map((d) => {
						const isSel = selectedDriver?.id === d.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
							className: "cursor-pointer",
							onClick: () => d.loadId && selectLoad(d.loadId),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
								x: d.x - 1.4,
								y: d.y - 1.1,
								width: "2.8",
								height: "2.2",
								rx: "0.35",
								fill: d.status === "offline" ? "var(--color-danger)" : "var(--color-primary)",
								stroke: isSel ? "var(--color-fg)" : "none",
								strokeWidth: isSel ? .4 : 0
							})
						}, d.id);
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-sm bg-bg/80 px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-muted",
					children: "San Pedro Bay"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "rounded-sm bg-bg/80 px-2 py-1 font-mono text-[10px] tabular-nums text-muted",
					children: [
						"710 +",
						i710?.delayMin ?? 0,
						"m"
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3 border-t border-border px-3 py-2 text-[10px] uppercase tracking-wide text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-ok" }), " Clear"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-warn" }), " Slow"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "size-2 rounded-full bg-danger" }), " Severe"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: cn("size-2 rounded-sm bg-primary") }), " Unit"]
					})
				]
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-medium uppercase tracking-wide", {
	variants: { tone: {
		muted: "bg-raised text-muted",
		primary: "bg-primary/15 text-primary",
		ok: "bg-ok/15 text-ok",
		warn: "bg-warn/15 text-warn",
		danger: "bg-danger/15 text-danger",
		info: "bg-info/15 text-info"
	} },
	defaultVariants: { tone: "muted" }
});
function Badge({ className, tone, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ tone }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-[opacity,transform,background-color,border-color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-raised text-fg border border-border hover:border-border-strong",
			ghost: "text-fg hover:bg-raised",
			danger: "bg-danger/15 text-danger hover:bg-danger/25",
			outline: "border border-border text-fg hover:bg-raised"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function ConditionsView() {
	const terminals = useDispatch((s) => s.terminals);
	const corridors = useDispatch((s) => s.corridors);
	const injectEvent = useDispatch((s) => s.injectEvent);
	const setView = useDispatch((s) => s.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-4 lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HarborMap, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-4 shadow-panel",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-medium",
					children: "Corridors"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-3",
					children: corridors.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-fg",
								children: c.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular-nums text-muted",
								children: [
									"+",
									c.delayMin,
									"m"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 h-1.5 overflow-hidden rounded-full bg-inset",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: cn("h-full rounded-full transition-[width] duration-300", c.congestion > 75 ? "bg-danger" : c.congestion > 40 ? "bg-warn" : "bg-ok"),
								style: { width: `${c.congestion}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: c.note
						})
					] }, c.id))
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full flex-col gap-3 lg:w-[380px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => injectEvent("traffic"),
						children: "Inject traffic event"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => injectEvent("terminal-line"),
						children: "Inject gate issue"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setView("planner"),
						children: "Replan from this"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-auto rounded-lg bg-surface shadow-panel",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase tracking-wider text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Terminal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Line"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-3 py-2 font-medium",
								children: "Wait"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: terminals.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-primary",
										children: t.code
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t.name }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: t.notes
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: t.gateStatus === "open" ? "ok" : t.gateStatus === "slow" ? "warn" : "danger",
									children: t.gateStatus
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs tabular-nums text-muted",
									children: [t.lineTrucks, " trucks"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-3 py-2.5 font-mono tabular-nums",
								children: [t.waitMin, "m"]
							})
						]
					}, t.id)) })]
				})
			})]
		})]
	});
}
var loadTone = {
	planned: "muted",
	dispatched: "info",
	"at-terminal": "primary",
	waiting: "warn",
	"en-route": "info",
	"at-customer": "primary",
	complete: "ok",
	hold: "danger"
};
var riskTone = {
	low: "ok",
	medium: "warn",
	high: "danger"
};
function StatusChip({ status }) {
	const tone = loadTone[status] ?? "muted";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone,
		children: STATUS_LABEL[status] ?? status
	});
}
function RiskChip({ risk }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		tone: riskTone[risk],
		children: risk
	});
}
function LiveDot({ on }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 text-xs text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-1.5 rounded-full ${on ? "bg-ok live-dot" : "bg-faint"}` }), on ? "MC3 live" : "MC3 idle"]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "waiting",
		label: "Waiting"
	},
	{
		id: "en-route",
		label: "En route"
	},
	{
		id: "hold",
		label: "Hold"
	},
	{
		id: "planned",
		label: "Planned"
	}
];
function DispatchBoard() {
	const loads = useDispatch((s) => s.loads);
	const drivers = useDispatch((s) => s.drivers);
	const terminals = useDispatch((s) => s.terminals);
	const selectedLoadId = useDispatch((s) => s.selectedLoadId);
	const selectLoad = useDispatch((s) => s.selectLoad);
	const mc3 = useDispatch((s) => s.mc3);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const visible = (0, import_react.useMemo)(() => {
		return [...filter === "all" ? loads : loads.filter((l) => l.status === filter)].sort((a, b) => {
			const rank = {
				high: 0,
				medium: 1,
				low: 2
			};
			return rank[a.risk] - rank[b.risk];
		});
	}, [loads, filter]);
	const selected = loads.find((l) => l.id === selectedLoadId) ?? visible[0];
	const kpis = {
		active: loads.filter((l) => l.status !== "complete" && l.status !== "planned").length,
		waiting: loads.filter((l) => l.status === "waiting" || l.status === "at-terminal").length,
		high: loads.filter((l) => l.risk === "high" && l.status !== "complete").length,
		avgWait: Math.round(terminals.filter((t) => t.kind === "marine").reduce((a, t) => a + t.waitMin, 0) / Math.max(1, terminals.filter((t) => t.kind === "marine").length))
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-4 lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-0 min-w-0 flex-1 flex-col gap-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						{
							k: "Active moves",
							v: kpis.active
						},
						{
							k: "In line",
							v: kpis.waiting
						},
						{
							k: "High risk",
							v: kpis.high
						},
						{
							k: "Avg terminal wait",
							v: `${kpis.avgWait}m`
						}
					].map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-surface p-3 shadow-panel",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-wider text-muted",
							children: x.k
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-mono text-xl tabular-nums text-fg",
							children: x.v
						})]
					}, x.k))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setFilter(f.id),
						className: cn("h-9 rounded-full px-3 text-xs font-medium transition-colors duration-150", filter === f.id ? "bg-primary text-primary-fg" : "bg-raised text-muted hover:text-fg"),
						children: f.label
					}, f.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 flex-1 overflow-auto rounded-lg bg-surface shadow-panel",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[640px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "sticky top-0 bg-surface text-[11px] uppercase tracking-wider text-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Move"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Lane"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Driver"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Wait"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "ETA"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-3 py-2 font-medium",
									children: "Risk"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((load) => {
							const d = driverById(drivers, load.driverId);
							const o = terminalById(terminals, load.originId);
							const dest = terminalById(terminals, load.destId);
							const active = selected?.id === load.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								onClick: () => selectLoad(load.id),
								className: cn("cursor-pointer border-t border-border transition-colors duration-150", active ? "bg-raised" : "hover:bg-raised/60"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-mono text-xs text-primary",
												children: load.container
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: load.status })]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3 py-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-fg",
											children: [
												o?.code,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "inline size-3 text-faint" }),
												" ",
												dest?.code
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted",
											children: load.customer
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-3 py-2.5",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: d?.name ?? "Unassigned" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-xs text-muted",
											children: d ? `#${d.truck}` : "—"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2.5 font-mono tabular-nums",
										children: load.waitMin > 0 ? `${load.waitMin}m` : "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2.5 font-mono tabular-nums text-muted",
										children: load.status === "complete" ? "done" : etaLabel(load.eta)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-3 py-2.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RiskChip, { risk: load.risk })
									})
								]
							}, load.id);
						}) })]
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "flex w-full shrink-0 flex-col gap-3 lg:w-[360px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HarborMap, {}),
				selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadDetail, { loadId: selected.id }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-surface p-4 text-sm text-muted shadow-panel",
					children: "Select a move."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden items-center justify-between rounded-lg bg-surface px-3 py-2 text-xs shadow-panel lg:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { on: mc3.connected }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-muted",
						children: mc3.lastSync ? formatClock(mc3.lastSync) : "no sync"
					})]
				})
			]
		})]
	});
}
function LoadDetail({ loadId }) {
	const load = useDispatch((s) => s.loads.find((l) => l.id === loadId));
	const drivers = useDispatch((s) => s.drivers);
	const terminals = useDispatch((s) => s.terminals);
	const assignDriver = useDispatch((s) => s.assignDriver);
	const updateLoadRoute = useDispatch((s) => s.updateLoadRoute);
	const setLoadStatus = useDispatch((s) => s.setLoadStatus);
	const setView = useDispatch((s) => s.setView);
	if (!load) return null;
	const driver = driverById(drivers, load.driverId);
	const origin = terminalById(terminals, load.originId);
	const dest = terminalById(terminals, load.destId);
	const free = drivers.filter((d) => d.status === "available" || d.id === load.driverId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-surface p-4 shadow-panel",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs text-primary",
						children: load.mc3MoveId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-base font-medium text-fg",
						children: load.container
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							load.size,
							" · ",
							load.type,
							" · ",
							load.ssl
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: load.status })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-3 grid grid-cols-2 gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] uppercase tracking-wider text-muted",
					children: "From"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [origin?.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block text-xs text-muted",
					children: [origin?.waitMin, "m wait"]
				})] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-[11px] uppercase tracking-wider text-muted",
					children: "To"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", { children: [dest?.name, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: load.customer
				})] })] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-fg",
				children: load.route
			}),
			load.altRoute ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: ["Alt: ", load.altRoute]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: load.notes
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 flex flex-wrap gap-1.5",
				children: load.legs.map((leg) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					tone: leg.status === "done" ? "ok" : leg.status === "active" ? "primary" : "muted",
					children: [
						leg.sequence,
						". ",
						leg.action,
						leg.appointment ? ` · ${leg.appointment}` : ""
					]
				}, leg.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-[11px] uppercase tracking-wider text-muted",
				children: ["Assign driver", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "mt-1 h-11 w-full rounded-sm border border-border bg-inset px-3 text-sm text-fg",
					value: load.driverId ?? "",
					onChange: (e) => {
						if (e.target.value) assignDriver(load.id, e.target.value);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Unassigned"
					}), free.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: d.id,
						children: [
							d.name,
							" · #",
							d.truck,
							" · HOS ",
							Math.round(d.hosRemainMin / 60),
							"h"
						]
					}, d.id))]
				})]
			}),
			driver ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 flex items-center gap-2 text-xs text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3" }),
					driver.locationLabel,
					" · ",
					driver.mc3Online ? "pinged" : "stale"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-wrap gap-2",
				children: [
					load.altRoute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => updateLoadRoute(load.id, load.altRoute),
						children: "Switch to alt route"
					}) : null,
					load.status !== "hold" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setLoadStatus(load.id, "hold"),
						children: "Hold"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => setLoadStatus(load.id, "dispatched"),
						children: "Release"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "ghost",
						onClick: () => setView("planner"),
						children: "Ask planner"
					})
				]
			})
		]
	});
}
var tone = {
	info: "info",
	watch: "warn",
	critical: "danger"
};
function EventsView() {
	const events = useDispatch((s) => s.events);
	const acknowledgeEvent = useDispatch((s) => s.acknowledgeEvent);
	const injectEvent = useDispatch((s) => s.injectEvent);
	const setView = useDispatch((s) => s.setView);
	const selectLoad = useDispatch((s) => s.selectLoad);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => injectEvent("weather"),
					children: "Fog event"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "secondary",
					onClick: () => injectEvent("chassis"),
					children: "Chassis lockout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => setView("planner"),
					children: "Replan from events"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-2 overflow-auto",
			children: events.map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: `rounded-lg bg-surface p-4 shadow-panel ${ev.acknowledged ? "opacity-60" : ""}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: tone[ev.severity],
								children: ev.severity
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: KIND_LABEL[ev.kind] ?? ev.kind }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted",
								children: formatClock(ev.at)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-2 text-sm font-medium",
						children: ev.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: ev.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [!ev.acknowledged ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => acknowledgeEvent(ev.id),
							children: "Acknowledge"
						}) : null, ev.loadId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "ghost",
							onClick: () => {
								selectLoad(ev.loadId);
								setView("dispatch");
							},
							children: "Open move"
						}) : null]
					})
				]
			}, ev.id))
		})]
	});
}
function FleetView() {
	const drivers = useDispatch((s) => s.drivers);
	const loads = useDispatch((s) => s.loads);
	const mc3 = useDispatch((s) => s.mc3);
	const selectLoad = useDispatch((s) => s.selectLoad);
	const setView = useDispatch((s) => s.setView);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-sm font-medium",
				children: "MC3 units"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { on: mc3.connected })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-2 sm:grid-cols-2 xl:grid-cols-3",
			children: drivers.map((d) => {
				const load = loads.find((l) => l.id === d.loadId);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => {
						if (load) {
							selectLoad(load.id);
							setView("dispatch");
						}
					},
					className: "rounded-lg bg-surface p-4 text-left shadow-panel transition-colors duration-150 hover:bg-raised",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: d.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted",
								children: ["Truck ", d.truck]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusChip, { status: d.status })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-fg",
							children: d.locationLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 flex flex-wrap gap-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: d.mc3Online ? "ok" : "danger",
									children: d.mc3Online ? "GPS" : "stale"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: d.hosRemainMin < 60 ? "danger" : "muted",
									children: ["HOS ", formatMinutes(d.hosRemainMin)]
								}),
								d.chassis ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "info",
									children: d.chassis
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "no chassis" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs text-primary",
							children: load ? load.container : "No move"
						})
					]
				}, d.id);
			})
		})]
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-sm border border-border bg-inset px-3 text-sm text-fg placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-sm border border-border bg-inset px-3 py-2 text-sm text-fg placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50", className),
		...props
	});
}
function MailView() {
	const mail = useDispatch((s) => s.mail);
	const selectedMailId = useDispatch((s) => s.selectedMailId);
	const selectMail = useDispatch((s) => s.selectMail);
	const markMailRead = useDispatch((s) => s.markMailRead);
	const sendMail = useDispatch((s) => s.sendMail);
	const mailbox = useDispatch((s) => s.mailbox);
	const pullMail = useDispatch((s) => s.pullMail);
	const drivers = useDispatch((s) => s.drivers);
	const loads = useDispatch((s) => s.loads);
	const selectLoad = useDispatch((s) => s.selectLoad);
	const setView = useDispatch((s) => s.setView);
	const [folder, setFolder] = (0, import_react.useState)("inbox");
	const [composing, setComposing] = (0, import_react.useState)(false);
	const [to, setTo] = (0, import_react.useState)("");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const list = (0, import_react.useMemo)(() => mail.filter((m) => m.folder === folder), [mail, folder]);
	const selected = mail.find((m) => m.id === selectedMailId) ?? list[0];
	function send() {
		if (!to.trim() || !subject.trim()) {
			toast.error("Add a recipient and subject.");
			return;
		}
		sendMail({
			to,
			subject,
			body,
			kind: "plan"
		});
		setTo("");
		setSubject("");
		setBody("");
		setComposing(false);
		setFolder("sent");
		toast.success(mailbox.connected ? "Sent from dispatch mailbox." : "Filed to Sent.");
	}
	function replyTemplate() {
		if (!selected) return;
		const driver = drivers.find((d) => d.id === selected.driverId);
		const load = loads.find((l) => l.id === selected.loadId);
		setComposing(true);
		setTo(selected.kind === "driver" ? selected.from : driver?.email || selected.from);
		setSubject(`Re: ${selected.subject}`);
		setBody(load ? `Updated plan for ${load.container} (${load.mc3MoveId}).\nRoute: ${load.route}\nStatus: ${load.status}\n\n— Pierline dispatch` : "Acknowledged. We are adjusting the plan.\n\n— Pierline dispatch");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-3 lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full shrink-0 flex-col lg:w-[320px]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-2 flex gap-1",
					children: [
						"inbox",
						"sent",
						"drafts"
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setFolder(f),
						className: cn("h-9 flex-1 rounded-full text-xs font-medium capitalize", folder === f ? "bg-primary text-primary-fg" : "bg-raised text-muted"),
						children: [f, f === "inbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 tabular-nums",
							children: mail.filter((m) => m.folder === "inbox" && !m.read).length || ""
						}) : null]
					}, f))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => setComposing(true),
						children: "Compose"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => pullMail(),
						disabled: !mailbox.connected,
						children: "Pull mail"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "min-h-0 flex-1 space-y-1 overflow-auto",
					children: [list.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => {
							selectMail(m.id);
							markMailRead(m.id);
							setComposing(false);
						},
						className: cn("w-full rounded-md px-3 py-2.5 text-left transition-colors duration-150", selected?.id === m.id ? "bg-raised" : "hover:bg-raised/60", !m.read && "border-l-2 border-l-primary"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm text-fg",
								children: m.subject
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted",
								children: m.from
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-mono text-[10px] text-faint",
								children: formatClock(m.at)
							})
						]
					}) }, m.id)), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "px-3 py-8 text-center text-sm text-muted",
						children: "Empty folder."
					}) : null]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1 rounded-lg bg-surface p-4 shadow-panel",
			children: composing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3",
				onSubmit: (e) => {
					e.preventDefault();
					send();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Dispatch email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "To",
						value: to,
						onChange: (e) => setTo(e.target.value),
						autoComplete: "off"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Subject",
						value: subject,
						onChange: (e) => setSubject(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						placeholder: "Plan, route, wait, and what changed.",
						value: body,
						onChange: (e) => setBody(e.target.value),
						className: "min-h-40"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Send"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setComposing(false),
							children: "Cancel"
						})]
					})
				]
			}) : selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: KIND_LABEL[selected.kind] ?? selected.kind }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-muted",
						children: formatClock(selected.at)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-lg font-medium leading-snug",
					children: selected.subject
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						selected.from,
						" → ",
						selected.to
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 whitespace-pre-wrap text-sm leading-relaxed text-fg",
					children: selected.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: replyTemplate,
						children: "Reply with plan"
					}), selected.loadId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "secondary",
						onClick: () => {
							selectLoad(selected.loadId);
							setView("dispatch");
						},
						children: "Open linked move"
					}) : null]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No message selected."
			})
		})]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var runDispatchPlan = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("590d90d41db4f918e83d17d274699f1b562764404d1cfca0f614867df53e7bdc"));
var askDispatchAi = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("b4fd987724749e9224106ac7e98a1317ab8ddeff93fe456a99018b584e38a27d"));
function PlannerView() {
	const state = useDispatch();
	const addPlan = useDispatch((s) => s.addPlan);
	const applyRecommendation = useDispatch((s) => s.applyRecommendation);
	const dismissRecommendation = useDispatch((s) => s.dismissRecommendation);
	const applyAllRecommendations = useDispatch((s) => s.applyAllRecommendations);
	const sendMail = useDispatch((s) => s.sendMail);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [question, setQuestion] = (0, import_react.useState)("");
	const [answer, setAnswer] = (0, import_react.useState)(null);
	const latest = state.plans[0];
	async function replan() {
		setBusy(true);
		setAnswer(null);
		try {
			const res = await runDispatchPlan({ data: {
				snapshot: buildPlannerSnapshot(useDispatch.getState()),
				question: question.trim() || void 0
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			addPlan(res.plan);
			toast.success("Plan ready — review before pushing to MC3.");
		} catch {
			toast.error("Planner could not run.");
		} finally {
			setBusy(false);
		}
	}
	async function ask() {
		if (!question.trim()) {
			toast.error("Type a dispatch question.");
			return;
		}
		setBusy(true);
		try {
			const res = await askDispatchAi({ data: {
				snapshot: buildPlannerSnapshot(useDispatch.getState()),
				question
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			setAnswer(res.text);
		} catch {
			toast.error("Planner could not answer.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col gap-4 lg:flex-row",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex w-full flex-col gap-3 lg:w-[380px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-surface p-4 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "AI dispatch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Reads live waits, lines, traffic, HOS, and unplanned events, then proposes routing and MC3 assignment changes."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						className: "mt-3",
						placeholder: "Optional: hold APM duals, rescue 2180, flip Brooks…",
						value: question,
						onChange: (e) => setQuestion(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: replan,
							disabled: busy,
							children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shimmer-text",
								children: "Scanning conditions"
							}) : "Replan board"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: ask,
							disabled: busy,
							children: "Ask"
						})]
					})
				]
			}), answer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-surface p-4 text-sm leading-relaxed text-fg shadow-panel whitespace-pre-wrap",
				children: answer
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-1 overflow-auto",
			children: !latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-surface p-8 text-center text-sm text-muted shadow-panel",
				children: "Run a replan when traffic, terminal lines, or a breakdown change the night."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg bg-surface p-4 shadow-panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: latest.riskLevel === "severe" ? "danger" : latest.riskLevel === "elevated" ? "warn" : "ok",
								children: latest.riskLevel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-muted",
								children: formatClock(latest.at)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed",
							children: latest.summary
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-3",
							size: "sm",
							onClick: () => {
								applyAllRecommendations(latest.id);
								toast.success("Applied to the board. MC3 push queued where connected.");
							},
							children: "Apply all"
						})
					]
				}), latest.recommendations.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-lg bg-surface p-4 shadow-panel",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: "primary",
									children: r.type
								}),
								r.minutesSaved > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: "ok",
									children: [formatMinutes(r.minutesSaved), " saved"]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									tone: r.status === "applied" ? "ok" : r.status === "dismissed" ? "muted" : "warn",
									children: r.status
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-sm font-medium",
							children: r.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: r.rationale
						}),
						r.newRoute ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs text-primary",
							children: r.newRoute
						}) : null,
						r.emailDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								"Draft to ",
								r.emailDraft.to,
								": ",
								r.emailDraft.subject
							]
						}) : null,
						r.status === "proposed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex flex-wrap gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									onClick: () => {
										applyRecommendation(latest.id, r.id);
										toast.success("Change applied.");
									},
									children: "Apply"
								}),
								r.emailDraft ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "secondary",
									onClick: () => {
										sendMail({
											to: r.emailDraft.to,
											subject: r.emailDraft.subject,
											body: r.emailDraft.body,
											kind: "plan",
											loadId: r.loadId,
											driverId: r.driverId
										});
										toast.success("Email filed to Sent.");
									},
									children: "Send email"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => dismissRecommendation(latest.id, r.id),
									children: "Dismiss"
								})
							]
						}) : null
					]
				}, r.id))]
			})
		})]
	});
}
function SettingsView() {
	const mc3 = useDispatch((s) => s.mc3);
	const mailbox = useDispatch((s) => s.mailbox);
	const syncLog = useDispatch((s) => s.syncLog);
	const connectMc3 = useDispatch((s) => s.connectMc3);
	const disconnectMc3 = useDispatch((s) => s.disconnectMc3);
	const syncMc3 = useDispatch((s) => s.syncMc3);
	const connectMailbox = useDispatch((s) => s.connectMailbox);
	const disconnectMailbox = useDispatch((s) => s.disconnectMailbox);
	const setAutoPush = useDispatch((s) => s.setAutoPush);
	const resetDemo = useDispatch((s) => s.resetDemo);
	const [tenant, setTenant] = (0, import_react.useState)(mc3.tenant);
	const [key, setKey] = (0, import_react.useState)("");
	const [env, setEnv] = (0, import_react.useState)(mc3.environment);
	const [address, setAddress] = (0, import_react.useState)(mailbox.address);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-3xl flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-4 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Trinium MC3"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { on: mc3.connected })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Link the driver app and TMS tenant used by this fleet. Pierline pulls GPS, geofence legs, and move status, then pushes assignment and route changes back to MC3."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted",
							children: ["Tenant host", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1",
								value: tenant,
								onChange: (e) => setTenant(e.target.value),
								placeholder: "pacificgate.trinium.cloud"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs text-muted",
							children: ["Integration key", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								className: "mt-1",
								type: "password",
								value: key,
								onChange: (e) => setKey(e.target.value),
								placeholder: "MC3 API key",
								autoComplete: "off"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "h-11 rounded-sm border border-border bg-inset px-3 text-sm",
							value: env,
							onChange: (e) => setEnv(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "sandbox",
								children: "Sandbox"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "production",
								children: "Production"
							})]
						}), mc3.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: () => syncMc3(),
							children: "Sync now"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => disconnectMc3(),
							children: "Disconnect"
						})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								connectMc3(tenant, key || "sandbox-demo-key", env);
								const err = useDispatch.getState().mc3.lastError;
								if (err) toast.error(err);
								else toast.success("MC3 linked. GPS and legs are live.");
							},
							children: "Connect MC3"
						})]
					}),
					mc3.lastError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-danger",
						children: mc3.lastError
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 flex min-h-11 items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: mc3.autoPush,
							onChange: (e) => setAutoPush(e.target.checked),
							className: "size-4 accent-primary"
						}), "Push accepted plan changes to MC3 automatically"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs text-muted",
						children: [
							"Last sync ",
							mc3.lastSync ? formatClock(mc3.lastSync) : "never",
							" · last push",
							" ",
							mc3.lastPush ? formatClock(mc3.lastPush) : "none"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-4 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-medium",
							children: "Dispatch mailbox"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: mailbox.connected ? "ok" : "muted",
							children: mailbox.connected ? "linked" : "local"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Inbound tenders, terminal advisories, and driver exception mail. Outbound plan changes go to drivers and customers."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 block text-xs text-muted",
						children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "mt-1",
							value: address,
							onChange: (e) => setAddress(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: mailbox.connected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => disconnectMailbox(),
							children: "Disconnect"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => {
								connectMailbox(address);
								toast.success("Mailbox linked.");
							},
							children: "Link mailbox"
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-lg bg-surface p-4 shadow-panel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-medium",
						children: "Integration log"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 max-h-56 space-y-2 overflow-auto font-mono text-xs text-muted",
						children: syncLog.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-faint",
								children: formatClock(e.at)
							}),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: e.direction === "in" ? "IN" : "OUT"
							}),
							" ",
							e.message
						] }, e.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						size: "sm",
						variant: "ghost",
						onClick: () => {
							resetDemo();
							toast.message("Demo board restored.");
						},
						children: "Reset demo board"
					})
				]
			})
		]
	});
}
var NAV = [
	{
		id: "dispatch",
		label: "Dispatch",
		icon: Container
	},
	{
		id: "conditions",
		label: "Conditions",
		icon: Map
	},
	{
		id: "fleet",
		label: "Fleet",
		icon: Truck
	},
	{
		id: "events",
		label: "Events",
		icon: TriangleAlert
	},
	{
		id: "mail",
		label: "Mail",
		icon: Mail
	},
	{
		id: "planner",
		label: "Planner",
		icon: Activity
	},
	{
		id: "settings",
		label: "Links",
		icon: Settings
	}
];
var MOBILE_NAV = [
	"dispatch",
	"conditions",
	"mail",
	"planner",
	"settings"
];
function DispatchShell() {
	const view = useDispatch((s) => s.view);
	const setView = useDispatch((s) => s.setView);
	const mc3 = useDispatch((s) => s.mc3);
	const mailbox = useDispatch((s) => s.mailbox);
	const events = useDispatch((s) => s.events);
	const mail = useDispatch((s) => s.mail);
	const tickSim = useDispatch((s) => s.tickSim);
	const syncMc3 = useDispatch((s) => s.syncMc3);
	const [clock, setClock] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const a = window.setInterval(() => setClock(Date.now()), 15e3);
		const b = window.setInterval(() => tickSim(), 8e3);
		const c = window.setInterval(() => {
			if (useDispatch.getState().mc3.connected) syncMc3();
		}, 28e3);
		return () => {
			window.clearInterval(a);
			window.clearInterval(b);
			window.clearInterval(c);
		};
	}, [tickSim, syncMc3]);
	const unread = mail.filter((m) => m.folder === "inbox" && !m.read).length;
	const openEvents = events.filter((e) => !e.acknowledged && e.severity !== "info").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden w-[220px] shrink-0 flex-col border-r border-border bg-surface md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-4 py-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium tracking-tight",
							children: "Pierline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Pacific Gate Drayage"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-0.5 px-2",
						children: NAV.map((item) => {
							const Icon = item.icon;
							const badge = item.id === "mail" ? unread : item.id === "events" ? openEvents : 0;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView(item.id),
								className: cn("flex h-11 items-center gap-2 rounded-sm px-3 text-sm transition-colors duration-150", view === item.id ? "bg-raised text-fg" : "text-muted hover:bg-raised/60 hover:text-fg"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-left",
										children: item.label
									}),
									badge > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-5 rounded-full bg-danger/20 px-1.5 text-center font-mono text-[10px] tabular-nums text-danger",
										children: badge
									}) : null
								]
							}, item.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-border px-4 py-4 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDot, { on: mc3.connected }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1",
							children: mailbox.connected ? mailbox.address : "Mailbox local"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex h-14 items-center justify-between gap-3 border-b border-border px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-sm font-medium md:hidden",
							children: "Pierline"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-sm text-muted md:block",
							children: "Harbor night shift · traffic, lines, waiting time"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 font-mono text-xs tabular-nums text-muted",
						children: [
							openEvents > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView("events"),
								className: "h-11 rounded-full bg-danger/15 px-3 text-danger",
								children: [openEvents, " events"]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden sm:inline",
								children: formatClock(clock)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setView("settings"),
								className: "inline-flex h-11 items-center gap-1 px-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-3.5" }), mc3.connected ? "MC3" : "offline"]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "flex min-h-0 flex-1 flex-col overflow-auto p-3 pb-24 md:p-5 md:pb-5",
					children: [
						view === "dispatch" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DispatchBoard, {}) : null,
						view === "conditions" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConditionsView, {}) : null,
						view === "fleet" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FleetView, {}) : null,
						view === "events" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EventsView, {}) : null,
						view === "mail" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailView, {}) : null,
						view === "planner" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlannerView, {}) : null,
						view === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-border bg-surface/95 pb-[env(safe-area-inset-bottom)] md:hidden",
				children: NAV.filter((n) => MOBILE_NAV.includes(n.id)).map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setView(item.id),
						className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[10px]", view === item.id ? "text-primary" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), item.label]
					}, item.id);
				})
			})
		]
	});
}
function Home() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg p-5 text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Pierline"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Loading the night board…"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-20 rounded-lg bg-surface shadow-panel" }, i))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DispatchShell, {});
}
//#endregion
export { Home as component };
