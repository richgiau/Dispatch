import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/planner-CoIC3zes.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function parsePlan(text, snapshot) {
	const jsonStart = text.indexOf("{");
	const jsonEnd = text.lastIndexOf("}");
	const raw = jsonStart >= 0 ? text.slice(jsonStart, jsonEnd + 1) : text;
	let parsed = {};
	try {
		parsed = JSON.parse(raw);
	} catch {
		parsed = {
			summary: text.slice(0, 800),
			riskLevel: "elevated",
			recommendations: []
		};
	}
	const recs = (parsed.recommendations ?? []).slice(0, 8).map((r, i) => {
		return {
			id: r.id && typeof r.id === "string" ? r.id : `rec-${i + 1}`,
			type: r.type || "reroute",
			title: String(r.title ?? "Adjustment"),
			rationale: String(r.rationale ?? ""),
			loadId: r.loadId,
			driverId: r.driverId,
			newRoute: r.newRoute,
			newDriverId: r.newDriverId,
			newStatus: r.newStatus,
			holdMinutes: r.holdMinutes,
			minutesSaved: Number(r.minutesSaved ?? 0) || 0,
			emailDraft: r.emailDraft,
			status: "proposed"
		};
	});
	return {
		id: `plan-${Date.now()}`,
		at: Date.now(),
		summary: String(parsed.summary ?? "Plan generated."),
		riskLevel: parsed.riskLevel === "severe" || parsed.riskLevel === "stable" ? parsed.riskLevel : "elevated",
		recommendations: recs
	};
}
var runDispatchPlan_createServerFn_handler = createServerRpc({
	id: "590d90d41db4f918e83d17d274699f1b562764404d1cfca0f614867df53e7bdc",
	name: "runDispatchPlan",
	filename: "src/lib/dispatch/planner.ts"
}, (opts) => runDispatchPlan.__executeServer(opts));
var runDispatchPlan = createServerFn({ method: "POST" }).validator((input) => input).handler(runDispatchPlan_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI dispatch is not available in this environment."
	};
	const question = data.question?.trim() || "Replan the board from current traffic, terminal lines, waiting time, HOS, chassis, and unplanned events. Change routing and assignments only where it saves time or prevents a missed window.";
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .3,
			max_tokens: 1600,
			response_format: { type: "json_object" },
			messages: [{
				role: "system",
				content: `You are Pierline, an AI dispatch engine for container drayage in San Pedro Bay (Los Angeles / Long Beach). The fleet runs on Trinium TMS with the MC3 driver app. You plan and replan moves using terminal wait times, gate lines, highway traffic, chassis pools, hours of service, appointments, and unplanned events.

Rules:
- Prefer concrete actions: reroute, reassign, hold, release, appointment shift, or email the driver/customer.
- Use only IDs present in the snapshot (load ids like mv-1044, driver ids like d-reyes).
- For reroutes, put the full new path in newRoute (e.g. "LBCT → I-605 → SR-60 → Ontario").
- For reassign, set newDriverId to an available driver id.
- minutesSaved must be a realistic integer.
- Include an emailDraft when a driver or customer must be told (to, subject, body). Use the emails in the snapshot.
- Do not invent terminals or trucks.
- 4 to 7 recommendations. Highest impact first.
- JSON only with shape:
{
  "summary": string,
  "riskLevel": "stable" | "elevated" | "severe",
  "recommendations": [{
    "id": string,
    "type": "reroute" | "reassign" | "hold" | "release" | "appointment" | "email",
    "title": string,
    "rationale": string,
    "loadId": string,
    "driverId": string,
    "newRoute": string,
    "newDriverId": string,
    "newStatus": "planned" | "dispatched" | "hold" | "en-route",
    "holdMinutes": number,
    "minutesSaved": number,
    "emailDraft": { "to": string, "subject": string, "body": string }
  }]
}`
			}, {
				role: "user",
				content: `${question}\n\nSNAPSHOT:\n${JSON.stringify(data.snapshot)}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`
	};
	return {
		ok: true,
		plan: parsePlan((await res.json()).choices[0]?.message.content ?? "", data.snapshot)
	};
});
var askDispatchAi_createServerFn_handler = createServerRpc({
	id: "b4fd987724749e9224106ac7e98a1317ab8ddeff93fe456a99018b584e38a27d",
	name: "askDispatchAi",
	filename: "src/lib/dispatch/planner.ts"
}, (opts) => askDispatchAi.__executeServer(opts));
var askDispatchAi = createServerFn({ method: "POST" }).validator((input) => input).handler(askDispatchAi_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI dispatch is not available in this environment."
	};
	const q = data.question?.trim();
	if (!q) return {
		ok: false,
		error: "Ask a dispatch question first."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .2,
			max_tokens: 700,
			messages: [{
				role: "system",
				content: "You are Pierline, a concise harbor dispatch assistant for Trinium MC3 drayage. Answer in 1–3 short paragraphs plus a bullet list of actions if needed. Use the snapshot. No markdown tables. No fluff."
			}, {
				role: "user",
				content: `${q}\n\nSNAPSHOT:\n${JSON.stringify(data.snapshot)}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`
	};
	return {
		ok: true,
		text: (await res.json()).choices[0]?.message.content ?? ""
	};
});
//#endregion
export { askDispatchAi_createServerFn_handler, runDispatchPlan_createServerFn_handler };
